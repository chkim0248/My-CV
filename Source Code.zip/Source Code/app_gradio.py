# -*- coding: utf-8 -*-
"""
app_gradio.py (FINAL INTEGRATED MASTER VERSION)
- 역할: 16R의 최신 UI(상세 견적 테이블 포함)와 기존 app_gradio의 로직을 완벽 통합
- 기능:
    1. STP 업로드 및 Online Inference (01S~13R 자동 실행)
    2. 공정별 상세 견적(Breakdown) 테이블 표시 (16R 기능 이식)
    3. 3D Overlay 뷰어 표시
    4. RAG + Gemini 기반 전문가 질의응답
    5. 실측값 피드백 및 재학습 트리거
- 수정: 코드 축약 없음, 원본 로직 100% 보존
"""

import os
import sys
import re
import html
import traceback
import gradio as gr
import pandas as pd
import numpy as np

# ----------------------------------------------------------------
# 1. 환경 설정 및 모듈 연결
# ----------------------------------------------------------------
# agent_core 패키지 경로 확보
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(current_dir)

try:
    # 핵심 엔진 임포트
    from agent_core.infer import online_infer
    from agent_core.rag import rag_search, rebuild_index
    from agent_core.live_store import LiveStore
    from agent_core.config import DIR_17R_DATA, DIR_13R_UID_REPORT
except ImportError as e:
    print("="*60)
    print(f"[CRITICAL ERROR] agent_core 모듈 로딩 실패: {e}")
    print("스크립트 실행 위치에 agent_core 폴더가 있는지 확인해주세요.")
    print("="*60)
    sys.exit(1)

# ----------------------------------------------------------------
# 2. 비즈니스 로직 (Controller)
# ----------------------------------------------------------------

def load_detail_report(uid):
    """
    [16R 기능 이식] 13R에서 생성한 상세 리포트(CSV)를 읽어와서 UI용 마크다운/표 데이터를 생성
    """
    if not uid: return "", None

    # 13R 결과 파일 탐색 (UID별 파일 우선, 없으면 전체 파일)
    csv_path = os.path.join(DIR_13R_UID_REPORT, f"S_UID_REPORT_{uid}.csv")
    if not os.path.exists(csv_path):
        csv_path = os.path.join(DIR_13R_UID_REPORT, "S_UID_REPORT.csv")
    
    if not os.path.exists(csv_path):
        return "(상세 리포트 파일 없음)", None

    try:
        # 인코딩 방어
        try:
            df = pd.read_csv(csv_path, encoding="utf-8-sig")
        except:
            df = pd.read_csv(csv_path, encoding="cp949")

        # 해당 UID 행 필터링
        if "uid" in df.columns:
            # 문자열 매칭 (UID_1001 or 1001)
            target = re.findall(r"\d+", str(uid))
            target_num = target[-1] if target else "000"
            df = df[df["uid"].astype(str).str.contains(target_num)]
        
        if df.empty:
            return "(해당 UID 데이터 없음)", None

        row = df.iloc[0]
        
        # 상세 공정 컬럼 추출 (13R V3 기준)
        # time_design_sum, time_cnc_sum ...
        breakdown_data = []
        headers = ["공정 구분", "시간 (분)", "비용 (추산)", "비고"]
        
        proc_map = {
            "design": "설계/CAM", "cnc": "NC 가공", "edm": "방전 가공", 
            "elec": "전극 제작", "polish": "사상/후가공", "weld": "용접/육성", "etc": "기타/셋업"
        }
        
        total_t = 0
        total_c = 0
        
        # 실제 계산된 총 비용
        total_cost_real = float(row.get("cost_krw_calib_uid", 0))
        
        # 각 공정별 시간 합산
        for key, label in proc_map.items():
            t_col = f"time_{key}_sum"
            t_val = float(row.get(t_col, 0))
            total_t += t_val
            
        # 테이블 데이터 생성
        for key, label in proc_map.items():
            t_col = f"time_{key}_sum"
            t_val = float(row.get(t_col, 0))
            
            # 비용 배분 (시간 비례 추산)
            c_val = 0
            if total_t > 0:
                c_val = total_cost_real * (t_val / total_t)
            
            # 0.1분 이상인 공정만 표시
            if t_val > 0.1: 
                breakdown_data.append([label, f"{t_val:.1f}분", f"{int(c_val):,}원", "-"])

        # 합계 행 추가
        breakdown_data.append(["✅ 합계", f"{total_t:.1f}분", f"{int(total_cost_real):,}원", "최종 견적"])
        
        # DataFrame 변환 (Gradio Dataframe 컴포넌트용)
        df_display = pd.DataFrame(breakdown_data, columns=headers)
        
        # 텍스트 요약 (13R에서 생성된 문구)
        breakdown_txt = str(row.get("process_breakdown_ko", "상세 내역 없음"))
        
        return breakdown_txt, df_display

    except Exception as e:
        return f"데이터 파싱 오류: {e}", None


def run_analysis_pipeline(before_file, after_file):
    """
    [분석 실행] 버튼 핸들러
    """
    if not before_file or not after_file:
        return (
            "⚠️ 파일을 모두 업로드해주세요.", # Summary
            None,                           # HTML Viewer
            None,                           # DataFrame (Breakdown)
            None,                           # Live Context
            "",                             # UID State
            "파일 누락"                      # Log
        )

    # 1. 추론 엔진 실행
    try:
        res = online_infer(before_file.name, after_file.name)
    except Exception as e:
        err = traceback.format_exc()
        return f"❌ 실행 오류:\n{err}", None, None, None, "", err

    # 2. 기본 결과 포맷팅
    t_val = res.time_min_calib_uid if res.time_min_calib_uid is not None else 0.0
    c_val = res.cost_krw_calib_uid if res.cost_krw_calib_uid is not None else 0.0
    n_patch = int(res.n_patch) if res.n_patch is not None else 0
    
    # 시간 변환 (분 -> 시간/분)
    h = int(t_val // 60)
    m = int(t_val % 60)
    time_str = f"{h}시간 {m}분 ({t_val:.1f}분)" if h > 0 else f"{t_val:.1f}분"
    cost_str = f"{int(c_val):,}원"

    # 3. 상세 리포트 로딩 (Breakdown)
    breakdown_txt, df_breakdown = load_detail_report(res.uid)

    # 4. 요약 마크다운 생성
    summary_md = f"""
    ### 🚀 분석 완료: **{res.uid}**
    
    | 구분 | 결과 값 |
    | :--- | :--- |
    | **총 소요 시간** | **{time_str}** |
    | **총 견적 비용** | **{cost_str}** |
    | **변경 패치 수** | {n_patch} 개 |
    
    #### 💡 공정 요약
    > {breakdown_txt}
    """

    # 5. RAG용 컨텍스트 생성 (챗봇이 참고할 정보)
    live_ctx = {
        "uid": res.uid,
        "time_calib": time_str,
        "cost_calib": cost_str,
        "n_patch": n_patch,
        "why_total": f"공정 상세: {breakdown_txt}"
    }

    # 6. 3D 뷰어 HTML 로드 (안전하게)
    html_content = "<div style='padding:50px; text-align:center; color:gray;'>3D 뷰어 생성 실패</div>"
    if res.overlay_html and os.path.exists(res.overlay_html):
        try:
            with open(res.overlay_html, "r", encoding="utf-8") as f:
                raw_html = f.read()
            
            # HTML Escape & Iframe (따옴표 오류 방지)
            escaped_html = html.escape(raw_html)
            html_content = f'''<iframe srcdoc="{escaped_html}" width="100%" height="600px" style="border:1px solid #ddd; border-radius:8px; background:white;"></iframe>'''
        except Exception as e:
            html_content = f"<div>뷰어 로드 에러: {e}</div>"

    return summary_md, html_content, df_breakdown, live_ctx, res.uid, res.logs


def chat_response(message, history, api_key, live_ctx):
    """채팅 응답 핸들러"""
    if not message: return ""
    if not live_ctx: live_ctx = {}

    try:
        # RAG 검색 (Gemini 자동 모델 탐색 포함)
        result = rag_search(
            query=message,
            k=3,
            gen_ai=True,
            api_key=api_key,
            live_context=live_ctx
        )
        return result.get("answer", "죄송합니다. 답변을 생성할 수 없습니다.")
    except Exception as e:
        return f"시스템 오류: {str(e)}"


def feedback_handler(uid, real_time, real_cost):
    """전문가 피드백 저장 핸들러"""
    if not uid: return "❌ 분석된 UID가 없습니다."
    
    gt_csv = os.path.join(DIR_17R_DATA, "S_UID_GT.csv")
    try:
        if os.path.exists(gt_csv):
            try: df = pd.read_csv(gt_csv, encoding="utf-8-sig")
            except: df = pd.read_csv(gt_csv, encoding="cp949")
        else:
            df = pd.DataFrame(columns=["uid", "time_min_measured", "cost_krw_measured"])
        
        # 덮어쓰기 로직
        df = df[df["uid"] != uid]
        new_row = {
            "uid": uid,
            "time_min_measured": float(real_time or 0),
            "cost_krw_measured": float(real_cost or 0),
            "uid_kind": "real_feedback"
        }
        df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
        df.to_csv(gt_csv, index=False, encoding="utf-8-sig")
        
        # 인덱스 재구축 (RAG 업데이트)
        msg = rebuild_index()
        return f"✅ 저장 완료 (UID: {uid})\n{msg}"
    except Exception as e:
        return f"❌ 저장 실패: {e}"


# ----------------------------------------------------------------
# 3. UI 레이아웃 (Gradio Blocks - 16R 스타일 적용)
# ----------------------------------------------------------------
# 커스텀 테마 적용
theme = gr.themes.Soft(
    primary_hue="blue",
    secondary_hue="slate",
).set(
    button_primary_background_fill="#1e40af", # 짙은 파랑
    button_primary_text_color="white",
    block_title_text_weight="bold"
)

with gr.Blocks(title="SF5 Intelligent Agent", theme=theme) as demo:
    
    # Session State
    state_ctx = gr.State({})
    state_uid = gr.State("")

    # Header
    gr.Markdown(
        """
        # 🏭 SF5 Intelligent Design Change Agent
        **3D 형상 분석**을 통해 설계 변경에 따른 **공정별 상세 비용**을 산출하고, **전문가 AI**와 상담할 수 있습니다.
        """
    )
    
    with gr.Row():
        # [Left Column] Controls
        with gr.Column(scale=1, min_width=350):
            with gr.Group():
                gr.Markdown("### 📂 파일 업로드")
                file_b = gr.File(label="변경 전 (Before STP)", file_count="single", file_types=[".stp", ".step"])
                file_a = gr.File(label="변경 후 (After STP)", file_count="single", file_types=[".stp", ".step"])
                btn_run = gr.Button("🚀 분석 실행 (Analyze)", variant="primary", size="lg")
            
            gr.Markdown("---")
            
            with gr.Group():
                gr.Markdown("### 🔧 전문가 피드백")
                gr.Markdown("AI 예측값을 보정하여 학습 데이터를 강화합니다.")
                with gr.Row():
                    num_time = gr.Number(label="실제 시간 (분)", precision=1)
                    num_cost = gr.Number(label="실제 비용 (원)", precision=0)
                btn_feed = gr.Button("💾 저장 및 재학습", size="sm")
                lbl_feed = gr.Label(label="상태", value="대기 중...", show_label=False)

            gr.Markdown("---")
            input_key = gr.Textbox(
                label="🔑 Gemini API Key", 
                type="password", 
                placeholder="AIzaSy... (API Key 입력)",
                info="키가 없으면 검색 결과만 표시됩니다."
            )

        # [Center Column] Report & Chat
        with gr.Column(scale=2, min_width=450):
            gr.Markdown("### 📊 분석 리포트 (Estimate)")
            md_summary = gr.Markdown(
                """
                <div style='padding:40px; text-align:center; background:#f3f4f6; border-radius:10px;'>
                    <h3 style='color:#9ca3af;'>분석 대기 중...</h3>
                    <p style='color:#9ca3af;'>좌측 패널에서 STP 파일을 업로드해주세요.</p>
                </div>
                """
            )
            
            # [NEW] 상세 공정 테이블 (DataFrame) - 16R 기능 이식
            gr.Markdown("#### 📋 공정별 상세 내역")
            df_breakdown = gr.Dataframe(
                headers=["공정 구분", "시간 (분)", "비용 (추산)", "비고"],
                datatype=["str", "str", "str", "str"],
                row_count=5,
                col_count=(4, "fixed"),
                interactive=False,
                label="Process Breakdown"
            )
            
            gr.Markdown("---")
            gr.Markdown("### 💬 AI 에이전트 (Expert Chat)")
            # [수정] ChatInterface 호환성 (height 제거)
            chatbot = gr.ChatInterface(
                fn=chat_response,
                additional_inputs=[input_key, state_ctx],
                textbox=gr.Textbox(placeholder="예: 왜 방전 비용이 높게 책정되었나요?", container=False, scale=7),
                submit_btn="질문하기",
                retry_btn=None,
                undo_btn=None,
                clear_btn="지우기"
            )

        # [Right Column] 3D Viewer & Logs
        with gr.Column(scale=2, min_width=450):
            gr.Markdown("### 🧊 3D 변경 부위 (Visualization)")
            html_viewer = gr.HTML(
                value="""
                <div style='height:600px; background:#fafafa; border:1px dashed #ccc; border-radius:8px; display:flex; align-items:center; justify-content:center; color:#999;'>
                    3D Viewer Ready
                </div>
                """,
                label="3D Viewer"
            )
            
            with gr.Accordion("시스템 로그 (System Logs)", open=False):
                txt_log = gr.Textbox(
                    label="Logs", 
                    lines=15, 
                    max_lines=30, 
                    interactive=False,
                    elem_id="log_box"
                )

    # ----------------------------------------------------------------
    # 4. 이벤트 바인딩
    # ----------------------------------------------------------------
    btn_run.click(
        fn=run_analysis_pipeline,
        inputs=[file_b, file_a],
        outputs=[md_summary, html_viewer, df_breakdown, state_ctx, state_uid, txt_log],
        show_progress=True
    )
    
    btn_feed.click(
        fn=feedback_handler,
        inputs=[state_uid, num_time, num_cost],
        outputs=[lbl_feed],
        show_progress=True
    )

if __name__ == "__main__":
    import re # 내부 사용 확인
    print("[INFO] SF5 Web Agent Starting...")
    
    demo.launch(
        server_name="0.0.0.0", 
        server_port=7860, 
        share=True, 
        inbrowser=True,
        allowed_paths=[os.path.abspath("..")]
    )