# ============================================================
# 15R_RAG_SEARCH_LOCAL_UID150_v7.py (FINAL FULL VERSION)
#
# [역할]
#   - 14R에서 생성된 KB CSV (S_AGENT_KNOWLEDGE_RAG.csv) 로드
#   - SentenceTransformer로 텍스트 임베딩 생성 및 FAISS 인덱싱 구축
#   - 콘솔(CMD) 환경에서 질의응답(RAG) 테스트 수행 및 검증
#
# [수정 사항]
#   - 경로 탐색 로직 강화 (resolve_root)
#   - 데이터 변경 감지 (Hash Check) 및 자동 Rebuild
#   - 코드 생략 없음 (Full Integrity)
# ============================================================

import os
import sys
import json
import time
import pickle
import argparse
import hashlib
import numpy as np
import pandas as pd
import warnings

# 경고 메시지 제어
warnings.filterwarnings("ignore")

# -----------------------------------------------------------------------------
# 1. 환경 설정 및 유틸리티
# -----------------------------------------------------------------------------
def _s(x: str) -> str:
    return str(x).encode("ascii", "ignore").decode("ascii")

def _print(msg: str):
    print(_s(msg))

def resolve_root(root_cli=None):
    """
    [핵심 수정] 실행 위치 기반 루트 경로 지능형 탐색
    """
    if root_cli: return os.path.abspath(root_cli)
    
    env_root = os.environ.get("SF5_ROOT", "").strip()
    if env_root: return os.path.abspath(env_root)
    
    here = os.path.abspath(os.path.dirname(__file__))
    
    # 1. 현재 위치에 데이터 폴더가 있으면, 현재 위치가 ROOT
    if os.path.isdir(os.path.join(here, "15R_RAG_INDEX")):
        return here
        
    # 2. 없으면 상위 폴더 확인
    parent = os.path.abspath(os.path.join(here, ".."))
    if os.path.isdir(os.path.join(parent, "15R_RAG_INDEX")):
        return parent
        
    return here

ROOT_DIR = resolve_root()

# -----------------------------------------------------------------------------
# 2. 라이브러리 로드 (Faiss / SentenceTransformers)
# -----------------------------------------------------------------------------
try:
    from sentence_transformers import SentenceTransformer
except ImportError:
    _print("[ERROR] sentence-transformers not installed.")
    _print("pip install sentence-transformers")
    sys.exit(1)

try:
    import faiss
except ImportError:
    _print("[WARN] faiss-cpu not installed. Using slower cosine similarity.")
    faiss = None

# -----------------------------------------------------------------------------
# 3. RAG 엔진 클래스 (핵심 로직)
# -----------------------------------------------------------------------------
class LocalRAGEngine:
    def __init__(self, base_dir):
        self.base_dir = base_dir
        self.kb_dir = os.path.join(base_dir, "14R_AGENT_KB")
        self.idx_dir = os.path.join(base_dir, "15R_RAG_INDEX")
        os.makedirs(self.idx_dir, exist_ok=True)

        self.csv_path = os.path.join(self.kb_dir, "S_AGENT_KNOWLEDGE_RAG.csv")
        
        # 인덱스 파일 경로
        self.path_emb = os.path.join(self.idx_dir, "embeddings.npy")
        self.path_meta = os.path.join(self.idx_dir, "meta.pkl")
        self.path_faiss = os.path.join(self.idx_dir, "faiss.index")
        self.path_hash = os.path.join(self.idx_dir, "kb_hash.txt")

        self.model = None
        self.df = None
        self.embeddings = None
        self.index = None

    def get_file_hash(self, path):
        """파일 변경 감지를 위한 해시 계산"""
        if not os.path.exists(path): return None
        h = hashlib.md5()
        try:
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    h.update(chunk)
            return h.hexdigest()
        except:
            return None

    def load_data(self, force_rebuild=False):
        """데이터 로드 및 인덱스 빌드/로딩 결정"""
        if not os.path.exists(self.csv_path):
            raise FileNotFoundError(f"KB CSV not found: {self.csv_path}\n(14R 스크립트를 먼저 실행하세요)")

        # CSV 로드
        try:
            self.df = pd.read_csv(self.csv_path, encoding="utf-8-sig")
        except:
            self.df = pd.read_csv(self.csv_path, encoding="cp949")
        
        # 데이터 정제 (NaN 제거)
        self.df = self.df.where(pd.notnull(self.df), "")
        
        _print(f"[15R] Loaded KB CSV: {len(self.df)} rows")

        # 재빌드 필요성 체크
        current_hash = self.get_file_hash(self.csv_path)
        saved_hash = None
        if os.path.exists(self.path_hash):
            with open(self.path_hash, "r") as f:
                saved_hash = f.read().strip()

        need_build = force_rebuild
        if current_hash != saved_hash:
            _print("[15R] KB file changed. Rebuilding index...")
            need_build = True
        elif not (os.path.exists(self.path_emb) and os.path.exists(self.path_meta)):
            _print("[15R] Index files missing. Rebuilding index...")
            need_build = True
        
        # 임베딩 파일과 데이터 개수 불일치 체크
        if not need_build and os.path.exists(self.path_emb):
            try:
                cached_emb = np.load(self.path_emb)
                if len(cached_emb) != len(self.df):
                    _print(f"[15R] Size mismatch (CSV:{len(self.df)} vs Emb:{len(cached_emb)}). Rebuilding...")
                    need_build = True
            except:
                need_build = True

        if need_build:
            self.build_index(current_hash)
        else:
            self.load_index()

    def build_index(self, current_hash):
        """임베딩 생성 및 FAISS 인덱스 구축"""
        _print("[15R] Building Index (Embedding)... This may take a while.")
        t0 = time.time()
        
        # 모델 로드
        self.model = SentenceTransformer("sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2")
        
        # 텍스트 준비
        # text_ko 컬럼 사용 (없으면 why_total_ko 등 대체)
        if "text_ko" not in self.df.columns:
            # 14R 생성 방식에 따라 컬럼명이 다를 수 있음
            cols = self.df.columns
            target_col = "text_ko"
            for c in ["text_ko", "why_total_ko", "summary"]:
                if c in cols:
                    target_col = c
                    break
            self.df["text_ko"] = self.df[target_col].astype(str)
        
        texts = self.df["text_ko"].fillna("").tolist()
        
        if not texts:
            _print("[15R][WARN] No texts to embed.")
            return

        # 임베딩 (Batch processing)
        self.embeddings = self.model.encode(texts, batch_size=32, show_progress_bar=True, normalize_embeddings=True)
        
        # 저장
        np.save(self.path_emb, self.embeddings)
        self.df.to_pickle(self.path_meta) # 메타데이터도 피클로 저장 (빠른 로딩)
        
        # 해시 저장
        if current_hash:
            with open(self.path_hash, "w") as f:
                f.write(current_hash)
        
        # FAISS 빌드
        if faiss:
            d = self.embeddings.shape[1]
            self.index = faiss.IndexFlatIP(d) # Inner Product (Cosine Similarity)
            self.index.add(self.embeddings)
            faiss.write_index(self.index, self.path_faiss)
            _print("[15R] FAISS index built and saved.")
        else:
            _print("[15R] FAISS not installed. Skipping index save.")
            
        _print(f"[15R] Indexing Done ({time.time()-t0:.1f}s)")

    def load_index(self):
        """저장된 인덱스 로드"""
        _print("[15R] Loading cached index...")
        self.embeddings = np.load(self.path_emb)
        self.df = pd.read_pickle(self.path_meta)
        
        if faiss and os.path.exists(self.path_faiss):
            self.index = faiss.read_index(self.path_faiss)
        
        # 모델은 검색 시 쿼리 인코딩 위해 필요
        self.model = SentenceTransformer("sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2")

    def search(self, query, k=3):
        """검색 실행"""
        if not query.strip(): return []
        
        # 쿼리 임베딩
        q_emb = self.model.encode([query], normalize_embeddings=True)
        
        results = []
        
        if self.index:
            # FAISS 검색
            D, I = self.index.search(np.array([q_emb]), k)
            for dist, idx in zip(D[0], I[0]):
                if idx < 0 or idx >= len(self.df): continue
                row = self.df.iloc[idx]
                results.append((row, float(dist)))
        else:
            # Numpy Cosine (Fallback)
            scores = np.dot(self.embeddings, q_emb.T).flatten()
            top_k_idx = np.argsort(scores)[::-1][:k]
            for idx in top_k_idx:
                row = self.df.iloc[idx]
                results.append((row, float(scores[idx])))
                
        return results

# -----------------------------------------------------------------------------
# 4. 메인 실행 로직
# -----------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=None)
    parser.add_argument("--query", default=None, help="Immediate query string")
    parser.add_argument("--top_k", type=int, default=3)
    parser.add_argument("--rebuild", action="store_true", help="Force rebuild index")
    # Pipeline compatibility args (ignored)
    parser.add_argument("--uid", default=None)
    parser.add_argument("--before", default=None)
    parser.add_argument("--after", default=None)
    parser.add_argument("--force", action="store_true")
    
    args = parser.parse_args()

    global ROOT_DIR
    if args.root:
        ROOT_DIR = os.path.abspath(args.root)

    _print("========================================")
    _print("===== 15R RAG SEARCH DEMO (V7) =====")
    _print(f"ROOT: {ROOT_DIR}")
    
    engine = LocalRAGEngine(ROOT_DIR)
    
    # 1. 로드 (Rebuild 옵션 처리)
    force = args.rebuild or args.force # pipeline force 옵션도 rebuild로 간주
    try:
        engine.load_data(force_rebuild=force)
    except Exception as e:
        _print(f"[ERROR] Engine load failed: {e}")
        return

    # 2. 검색 모드 (Interactive vs One-shot)
    if args.query:
        # 단발성 검색 (배치 파일 등에서 호출 시)
        do_search(engine, args.query, args.top_k)
    else:
        # 인터랙티브 모드 (사용자 직접 실행 시)
        _print("\n[Input Loop] 질문을 입력하세요 (종료: 'q')")
        while True:
            try:
                # 한글 입력 문제 방지를 위한 프롬프트
                sys.stdout.write("\n질문> ")
                sys.stdout.flush()
                q = sys.stdin.readline().strip()
            except (EOFError, KeyboardInterrupt):
                break
                
            if q.lower() in ["q", "quit", "exit"]:
                break
            if not q: continue
            
            do_search(engine, q, args.top_k)

def do_search(engine, query, k):
    t0 = time.time()
    results = engine.search(query, k=k)
    dt = time.time() - t0
    
    _print(f"\n[검색 결과: '{query}'] (소요시간: {dt:.3f}s)")
    if not results:
        _print("검색 결과가 없습니다.")
        return

    for i, (row, score) in enumerate(results):
        uid = str(row.get("uid", "?"))
        doc_id = str(row.get("doc_id", "?"))
        level = str(row.get("level", "?"))
        
        # 텍스트 내용 포맷팅 (상세 내용 잘 보이게)
        text = str(row.get("text_ko", "")).strip()
        preview = text.replace("\n", " ")
        if len(preview) > 150: preview = preview[:150] + "..."
        
        print(f"\n[{i+1}] Score: {score:.4f} | UID: {uid} | Level: {level}")
        print("-" * 60)
        print(text)
        print("-" * 60)

if __name__ == "__main__":
    main()