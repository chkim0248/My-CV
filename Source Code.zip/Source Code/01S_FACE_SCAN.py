# ============================================================
# 01S_FACE_SCAN.py  (CRITICAL FIX: Ignore SameFileError)
#  - 원본/대상 같으면 에러 무시하고 진행 (덮어쓰기 효과)
# ============================================================

import os
import sys
import shutil
import time
import json
import math
import argparse
from dataclasses import asdict, dataclass
from typing import List, Dict, Any, Optional

import numpy as np

# ----------------- 출력 유틸 -----------------
def safe_print(*args):
    msg = " ".join(str(a) for a in args)
    try:
        print(msg)
    except UnicodeEncodeError:
        try:
            sys.stdout.buffer.write((msg + "\n").encode("utf-8", errors="ignore"))
        except Exception:
            pass

# ----------------- pythonocc import -----------------
try:
    from OCC.Core.STEPControl import STEPControl_Reader
    from OCC.Core.IFSelect import IFSelect_RetDone
    from OCC.Core.Bnd import Bnd_Box
    from OCC.Core.BRepBndLib import brepbndlib_Add
    from OCC.Core.TopAbs import TopAbs_FACE
    from OCC.Core.TopExp import TopExp_Explorer
    from OCC.Core.TopoDS import topods_Face, TopoDS_Shape
    from OCC.Core.BRep import BRep_Tool
    from OCC.Core.TopLoc import TopLoc_Location
    from OCC.Core.GeomAdaptor import GeomAdaptor_Surface
    from OCC.Core.GProp import GProp_GProps
    from OCC.Core.BRepGProp import brepgprop_SurfaceProperties
    from OCC.Core.GeomLProp import GeomLProp_SLProps
    from OCC.Core.BRepMesh import BRepMesh_IncrementalMesh
except ImportError as e:
    safe_print("pythonocc-core import 실패:", e)
    sys.exit(1)

# ----------------- 데이터 클래스 -----------------
@dataclass
class FaceInfo:
    index: int
    surf_type: str
    surf_type_code: int
    area: float
    bbox: Dict[str, float]
    center: List[float]
    normal_avg: List[float]
    bbox_diag: float

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        b = self.bbox
        d["bbox"] = {
            "xmin": float(round(b["xmin"], 6)),
            "ymin": float(round(b["ymin"], 6)),
            "zmin": float(round(b["zmin"], 6)),
            "xmax": float(round(b["xmax"], 6)),
            "ymax": float(round(b["ymax"], 6)),
            "zmax": float(round(b["zmax"], 6)),
        }
        d["area"]       = float(round(self.area, 6))
        d["bbox_diag"]  = float(round(self.bbox_diag, 6))
        d["center"]     = [float(round(c, 6)) for c in self.center]
        d["normal_avg"] = [float(round(c, 6)) for c in self.normal_avg]
        return d

# ----------------- 기하 유틸 -----------------
def mesh_shape(shape: TopoDS_Shape, deflection: float = 1.0, angle: float = 0.5):
    try:
        _ = BRepMesh_IncrementalMesh(shape, deflection, True, angle, True)
    except Exception as e:
        safe_print("메싱 경고:", e)

def load_step_shape(path: str) -> TopoDS_Shape:
    reader = STEPControl_Reader()
    status = reader.ReadFile(path)
    if status != IFSelect_RetDone:
        raise RuntimeError(f"STEP 읽기 실패: {path}")
    reader.TransferRoots()
    shape = reader.OneShape()
    mesh_shape(shape, deflection=1.0, angle=0.5)
    return shape

def calc_bbox(shape: TopoDS_Shape) -> Dict[str, float]:
    box = Bnd_Box()
    brepbndlib_Add(shape, box, True)
    xmin, ymin, zmin, xmax, ymax, zmax = box.Get()
    return dict(xmin=xmin, ymin=ymin, zmin=zmin,
                xmax=xmax, ymax=ymax, zmax=zmax)

def bbox_diag(b: Dict[str, float]) -> float:
    dx = b["xmax"] - b["xmin"]
    dy = b["ymax"] - b["ymin"]
    dz = b["zmax"] - b["zmin"]
    return math.sqrt(dx*dx + dy*dy + dz*dz)

def bbox_center(b: Dict[str, float]) -> List[float]:
    return [
        0.5 * (b["xmax"] + b["xmin"]),
        0.5 * (b["ymax"] + b["ymin"]),
        0.5 * (b["zmax"] + b["zmin"]),
    ]

def surface_type_info(face) -> (str, int):
    h_surf = BRep_Tool.Surface(face)
    adaptor = GeomAdaptor_Surface(h_surf)
    t = adaptor.GetType()
    type_map = {
        0: "Plane", 1: "Cylinder", 2: "Cone", 3: "Sphere", 4: "Torus",
        5: "BezierSurface", 6: "BSplineSurface", 7: "SurfaceOfRevolution",
        8: "SurfaceOfExtrusion", 9: "OtherSurface",
    }
    return type_map.get(int(t), f"Unknown_{int(t)}"), int(t)

def face_area(face) -> float:
    props = GProp_GProps()
    brepgprop_SurfaceProperties(face, props)
    return props.Mass()

def face_avg_normal(face) -> List[float]:
    loc = TopLoc_Location()
    triangulation = BRep_Tool.Triangulation(face, loc)
    if triangulation is not None and triangulation.NbTriangles() > 0:
        nb_nodes = triangulation.NbNodes()
        nb_tris  = triangulation.NbTriangles()
        trsf = loc.Transformation()
        use_trsf = not loc.IsIdentity()
        nodes = []
        for i in range(1, nb_nodes + 1):
            pnt = triangulation.Node(i)
            if use_trsf: pnt = pnt.Transformed(trsf)
            nodes.append(np.array([pnt.X(), pnt.Y(), pnt.Z()], dtype=np.float64))
        n_sum = np.zeros(3, dtype=np.float64)
        cnt = 0
        for i in range(1, nb_tris + 1):
            tri = triangulation.Triangle(i)
            i1, i2, i3 = tri.Get()
            v1, v2, v3 = nodes[i1 - 1], nodes[i2 - 1], nodes[i3 - 1]
            n = np.cross(v2 - v1, v3 - v1)
            norm = np.linalg.norm(n)
            if norm > 0:
                n_sum += n / norm
                cnt += 1
        if cnt > 0:
            n_avg = n_sum / float(cnt)
            norm = np.linalg.norm(n_avg)
            if norm > 0: n_avg /= norm
            return n_avg.tolist()
    h_surf = BRep_Tool.Surface(face)
    adaptor = GeomAdaptor_Surface(h_surf)
    um = 0.5 * (adaptor.FirstUParameter() + adaptor.LastUParameter())
    vm = 0.5 * (adaptor.FirstVParameter() + adaptor.LastVParameter())
    props = GeomLProp_SLProps(h_surf, um, vm, 1, 1e-6)
    if props.IsNormalDefined():
        n = props.Normal()
        n_vec = np.array([n.X(), n.Y(), n.Z()], dtype=np.float64)
        norm = np.linalg.norm(n_vec)
        if norm > 0: n_vec /= norm
        return n_vec.tolist()
    return [0.0, 0.0, 1.0]

def scan_faces(shape: TopoDS_Shape) -> List[FaceInfo]:
    faces: List[FaceInfo] = []
    exp = TopExp_Explorer(shape, TopAbs_FACE)
    idx = 0
    while exp.More():
        face = topods_Face(exp.Current())
        b = calc_bbox(face)
        faces.append(FaceInfo(
            index=idx,
            surf_type=surface_type_info(face)[0],
            surf_type_code=surface_type_info(face)[1],
            area=face_area(face),
            bbox=b,
            center=bbox_center(b),
            normal_avg=face_avg_normal(face),
            bbox_diag=bbox_diag(b),
        ))
        idx += 1
        exp.Next()
    return faces

def faces_to_list(faces: List[FaceInfo]) -> List[Dict[str, Any]]:
    return [f.to_dict() for f in faces]

# ----------------- 경로/IO -----------------
def resolve_root(root_cli: Optional[str]) -> str:
    if root_cli:
        return os.path.abspath(root_cli)
    here = os.path.abspath(os.path.dirname(__file__))
    return os.path.abspath(os.path.join(here, ".."))

def prepare_live_raw(root: str, uid: str, before_path: str, after_path: str) -> str:
    live_raw_root = os.path.join(root, "01_raw_L0", "_LIVE", uid)
    os.makedirs(live_raw_root, exist_ok=True)
    
    dst_before = os.path.join(live_raw_root, f"{uid}_before.stp")
    dst_after  = os.path.join(live_raw_root, f"{uid}_after.stp")
    
    # [수정됨] 무조건 복사 시도하되, 같은 파일이면 에러 무시
    try:
        shutil.copy2(before_path, dst_before)
    except shutil.SameFileError:
        pass  # 이미 거기 있으니 OK
    except Exception as e:
        safe_print(f"[WARN] before copy failed: {e}")

    try:
        shutil.copy2(after_path, dst_after)
    except shutil.SameFileError:
        pass  # 이미 거기 있으니 OK
    except Exception as e:
        safe_print(f"[WARN] after copy failed: {e}")
        
    return live_raw_root

# ----------------- 메인 처리 -----------------
def process_one_uid(root: str, raw_dir: str, uid: str, force: bool = False):
    before_path = os.path.join(raw_dir, f"{uid}_before.stp")
    after_path  = os.path.join(raw_dir, f"{uid}_after.stp")

    safe_print("\n==================================================")
    safe_print(f"[{uid}] FACE_SCAN 시작")
    
    if not os.path.isfile(before_path):
        safe_print("  경고: before STEP 파일 없음 -> 스킵")
        return
    if not os.path.isfile(after_path):
        safe_print("  경고: after STEP 파일 없음 -> 스킵")
        return

    out_dir  = os.path.join(root, "01S_FACE_SCAN", uid)
    out_json = os.path.join(out_dir, f"{uid}_FACE_INFO.json")
    os.makedirs(out_dir, exist_ok=True)

    env_force = os.environ.get("SF5_FORCE_REBUILD", "0") == "1"
    if (not force) and (not env_force) and os.path.isfile(out_json):
        safe_print(f"[{uid}] 기존 JSON 존재 -> 재활용:", out_json)
        return

    t0 = time.time()
    safe_print(f"[{uid}] STEP 로드/메싱 중 ...")
    shape_before = load_step_shape(before_path)
    shape_after  = load_step_shape(after_path)
    safe_print(f"[{uid}] STEP 로드/메싱 완료")

    bbox_b = calc_bbox(shape_before)
    bbox_a = calc_bbox(shape_after)
    bbox_u = {
        "xmin": min(bbox_b["xmin"], bbox_a["xmin"]),
        "ymin": min(bbox_b["ymin"], bbox_a["ymin"]),
        "zmin": min(bbox_b["zmin"], bbox_a["zmin"]),
        "xmax": max(bbox_b["xmax"], bbox_a["xmax"]),
        "ymax": max(bbox_b["ymax"], bbox_a["ymax"]),
        "zmax": max(bbox_b["zmax"], bbox_a["zmax"]),
    }
    diag_u = bbox_diag(bbox_u)

    safe_print(f"[{uid}] before faces 스캔 ...")
    faces_before = scan_faces(shape_before)
    safe_print(f"[{uid}] after  faces 스캔 ...")
    faces_after = scan_faces(shape_after)

    data = {
        "uid": uid,
        "bbox_before": bbox_b,
        "bbox_after": bbox_a,
        "bbox_union": bbox_u,
        "diag_mm": float(round(diag_u, 6)),
        "before": {"n_faces": len(faces_before), "faces": faces_to_list(faces_before)},
        "after":  {"n_faces": len(faces_after),  "faces": faces_to_list(faces_after)},
    }

    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    safe_print(f"[{uid}] FACE_SCAN JSON 저장:", out_json)
    safe_print(f"[{uid}] 총 소요 시간: {time.time()-t0:.1f} s")

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--root", default=None)
    p.add_argument("--uid", default=None)
    p.add_argument("--before", default=None)
    p.add_argument("--after", default=None)
    p.add_argument("--force", action="store_true")
    p.add_argument("--uid_start", type=int, default=None)
    p.add_argument("--uid_end",   type=int, default=None)
    args = p.parse_args()

    env_root = os.environ.get("SF5_ROOT")
    if args.root:
        root = os.path.abspath(args.root)
    elif env_root:
        root = os.path.abspath(env_root)
    else:
        root = resolve_root(None)

    # 1) 온라인 모드
    if args.before and args.after:
        uid = args.uid if args.uid else "LIVE_001"
        raw_dir_live = prepare_live_raw(root, uid, args.before, args.after)
        safe_print("===== 01S_FACE_SCAN : ONLINE 1-PAIR =====")
        process_one_uid(root, raw_dir_live, uid, force=args.force)
        safe_print("===== 01S_FACE_SCAN : ONLINE DONE =====")
        return

    # 2) 배치 모드
    raw_dir = os.path.join(root, "01_raw_L0")
    safe_print("===== 01S_FACE_SCAN : BATCH =====")
    
    if args.uid_start is not None and args.uid_end is not None:
        uid_list = [f"UID_{i:03d}" for i in range(args.uid_start, args.uid_end + 1)]
    else:
        uid_list = [f"UID_{i:03d}" for i in range(1, 15)]

    for uid in uid_list:
        try:
            process_one_uid(root, raw_dir, uid, force=args.force)
        except Exception as e:
            safe_print(f"[WARN] {uid} 예외: {e}")

    safe_print("===== 01S_FACE_SCAN : BATCH DONE =====")

if __name__ == "__main__":
    main()