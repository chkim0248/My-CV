# ============================================================
# 03S_FACE_UV_DIFF.py  (CRITICAL FIX: SameFileError Ignored)
#
# 역할
#   - 01S, 02S 결과를 사용해 매칭된 Face Pair의 형상 차이(Patch) 추출
#   - 수정사항: 
#     1. _prepare_live_raw 함수에서 shutil.SameFileError 무시 처리
#     2. FACE_INFO, FACE_MATCH json 파일 탐색 시 UID_xxx / xxx 폴더 모두 확인
# ============================================================

import os, sys, json, time, math, argparse, shutil
from typing import List, Dict, Any, Tuple

import numpy as np

# ----------------- 출력 유틸 -----------------
def safe_print(*args):
    msg = " ".join(str(a) for a in args)
    try:
        print(msg)
    except UnicodeEncodeError:
        try:
            sys.stdout.buffer.write((msg + "\n").encode("utf-8", errors="ignore"))
        except Exception:
            pass

# ----------------- 경로 리졸버 -----------------
def resolve_root(root_cli=None):
    if root_cli: return os.path.abspath(root_cli)
    env_root = os.environ.get("SF5_ROOT", "").strip()
    if env_root: return os.path.abspath(env_root)
    here = os.path.abspath(os.path.dirname(__file__))
    return os.path.abspath(os.path.join(here, ".."))

# ----------------- pythonocc-core -----------------
try:
    from OCC.Core.STEPControl import STEPControl_Reader
    from OCC.Core.IFSelect import IFSelect_RetDone
    from OCC.Core.TopExp import TopExp_Explorer
    from OCC.Core.TopAbs import TopAbs_FACE
    from OCC.Core.TopoDS import TopoDS_Shape, topods_Face
    from OCC.Core.BRep import BRep_Tool
    from OCC.Core.BRepTools import breptools_UVBounds
    from OCC.Core.GeomLProp import GeomLProp_SLProps
except ImportError as e:
    safe_print("pythonocc-core import failed:", e)
    sys.exit(1)

# ----------------- SciPy(ndimage) 옵션 -----------------
_USE_NDIMAGE = True
try:
    from scipy import ndimage
except Exception:
    _USE_NDIMAGE = False
    safe_print("[WARN] scipy.ndimage not found -> using manual BFS labeling")

# ----------------- 파라미터 -----------------
PARAMS = {
    "quick_n_points": 5,             # 중앙1 + 모서리4
    "quick_delta_small_mm": 0.02,    # 0.02mm 미만: 변화 없음
    "fine_grid_u": 18,
    "fine_grid_v": 18,
    "patch_delta_mm": 0.05,          # |Δ|>=0.05mm -> patch 후보
    "min_face_area_for_sampling": 1.0,  # 1mm^2 미만 면 생략
    "min_component_area_mm2": 0.5,      # 신규/삭제 너무 작은 면 생략
}

# ----------------- STEP/기하 유틸 -----------------
def _safe_norm(v: np.ndarray) -> float:
    return float(np.linalg.norm(v))

def load_step_shape(path: str) -> TopoDS_Shape:
    rdr = STEPControl_Reader()
    st  = rdr.ReadFile(path)
    if st != IFSelect_RetDone:
        raise RuntimeError(f"STEP read failed: {path}")
    rdr.TransferRoots()
    return rdr.OneShape()

def collect_faces(shape: TopoDS_Shape) -> List:
    faces = []
    exp = TopExp_Explorer(shape, TopAbs_FACE)
    while exp.More():
        faces.append(topods_Face(exp.Current()))
        exp.Next()
    return faces

def eval_point_normal_on_face(face, u: float, v: float) -> Tuple[np.ndarray, np.ndarray]:
    h = BRep_Tool.Surface(face)
    props = GeomLProp_SLProps(h, u, v, 1, 1e-6)
    p = props.Value()
    pt = np.array([p.X(), p.Y(), p.Z()], dtype=np.float64)
    if props.IsNormalDefined():
        n = props.Normal()
        nvec = np.array([n.X(), n.Y(), n.Z()], dtype=np.float64)
        nrm = float(np.linalg.norm(nvec))
        if nrm > 0: nvec /= nrm
    else:
        nvec = np.array([0.0, 0.0, 1.0], dtype=np.float64)
    return pt, nvec

def compute_delta_normal(face_b, face_a, samples_uv: List[Tuple[float, float]]) -> List[float]:
    deltas = []
    for (u, v) in samples_uv:
        xb, nb = eval_point_normal_on_face(face_b, u, v)
        xa, _  = eval_point_normal_on_face(face_a, u, v)
        deltas.append(float(np.dot(xa - xb, nb)))
    return deltas

def make_bbox_3d(points: np.ndarray) -> Dict[str, float]:
    if points.shape[0] == 0:
        return dict(xmin=0, ymin=0, zmin=0, xmax=0, ymax=0, zmax=0)
    mn = points.min(axis=0); mx = points.max(axis=0)
    return dict(
        xmin=float(mn[0]), ymin=float(mn[1]), zmin=float(mn[2]),
        xmax=float(mx[0]), ymax=float(mx[1]), zmax=float(mx[2]),
    )

# ----------------- 연결 성분 레이블링 -----------------
def _label_components_binary(mask: np.ndarray) -> Tuple[np.ndarray, int]:
    if _USE_NDIMAGE:
        labeled, n = ndimage.label(mask.astype(np.int32))
        return labeled, int(n)
    # SciPy 미설치 시 BFS 4-연결
    h, w = mask.shape
    labeled = np.zeros((h, w), dtype=np.int32)
    n = 0
    dirs = [(1,0),(-1,0),(0,1),(0,-1)]
    for y in range(h):
        for x in range(w):
            if mask[y,x] and labeled[y,x]==0:
                n += 1
                q = [(y,x)]
                labeled[y,x] = n
                while q:
                    cy, cx = q.pop()
                    for dy, dx in dirs:
                        ny, nx = cy+dy, cx+dx
                        if 0<=ny<h and 0<=nx<w and mask[ny,nx] and labeled[ny,nx]==0:
                            labeled[ny,nx]=n
                            q.append((ny,nx))
    return labeled, n

def summarize_patch(face_b, u_vals, v_vals, mask_patch, delta_grid, area_face) -> Dict[str, Any]:
    idx = np.argwhere(mask_patch)
    if idx.size == 0:
        return None
    deltas = delta_grid[mask_patch]
    davg = float(np.mean(deltas))
    dmax = float(np.max(deltas))
    dmin = float(np.min(deltas))
    sign = "thicker" if davg > 1e-3 else ("thinner" if davg < -1e-3 else "mixed")

    pts = []
    H, W = delta_grid.shape
    for (iv, iu) in idx:
        u = u_vals[iu]; v = v_vals[iv]
        xb, _ = eval_point_normal_on_face(face_b, u, v)
        pts.append(xb)
    pts = np.array(pts, dtype=np.float64)
    center = pts.mean(axis=0)
    bbox   = make_bbox_3d(pts)

    total = float(H*W)
    area_ratio = idx.shape[0]/total
    area_est   = float(area_face * area_ratio)

    return {
        "sign": sign,
        "delta_avg": round(davg, 6),
        "delta_max": round(dmax, 6),
        "delta_min": round(dmin, 6),
        "n_samples": int(idx.shape[0]),
        "center_3d": [float(round(c,6)) for c in center.tolist()],
        "bbox_3d":   {k: float(round(v,6)) for k,v in bbox.items()},
        "area_est":  float(round(area_est,6)),
    }

# ----------------- 본 처리 -----------------
def _find_json_path(base_dir, uid, filename_fmt):
    """UID_xxx 또는 xxx 폴더 모두 탐색"""
    # 1. UID_xxx/filename
    p1 = os.path.join(base_dir, uid, filename_fmt.format(uid=uid))
    if os.path.isfile(p1): return p1
    
    # 2. xxx/filename (숫자만 있는 폴더)
    import re
    m = re.search(r"(\d+)", uid)
    if m:
        num_str = str(int(m.group(1))) # '151'
        p2 = os.path.join(base_dir, num_str, filename_fmt.format(uid=uid))
        if os.path.isfile(p2): return p2
        # 파일명도 UID_ 없이 생성되었을 가능성? (01S는 UID_xxx 형식을 따르도록 수정됨)
    return p1 # Default path to report error on

def process_one_uid(root: str, uid: str, force: bool=False):
    # 경로 구성
    raw_dir   = os.path.join(root, "01_raw_L0")
    scan_dir  = os.path.join(root, "01S_FACE_SCAN")
    match_dir = os.path.join(root, "02S_FACE_MATCH")
    out_dir   = os.path.join(root, "03S_FACE_UV_DIFF", uid)
    os.makedirs(out_dir, exist_ok=True)

    scan_path  = _find_json_path(scan_dir, uid, "{uid}_FACE_INFO.json")
    match_path = _find_json_path(match_dir, uid, "{uid}_FACE_MATCH.json")
    out_path   = os.path.join(out_dir, f"{uid}_UV_DIFF.json")

    safe_print("="*50)
    safe_print(f"[{uid}] 03S_FACE_UV_DIFF start")

    if not os.path.isfile(scan_path):
        safe_print(f"skip: FACE_INFO not found -> {scan_path}"); return
    if not os.path.isfile(match_path):
        safe_print(f"skip: FACE_MATCH not found -> {match_path}"); return

    env_force = os.environ.get("SF5_FORCE_REBUILD","0")=="1"
    if os.path.isfile(out_path) and not (force or env_force):
        safe_print(f"[{uid}] reuse existing -> {out_path}")
        return

    t0 = time.time()
    with open(scan_path, "r", encoding="utf-8") as f: info  = json.load(f)
    with open(match_path,"r", encoding="utf-8") as f: match = json.load(f)

    diag = float(info.get("diag_mm", 1.0)) or 1.0
    Bfaces_info = info["before"]["faces"]; Afaces_info = info["after"]["faces"]
    pairs       = match.get("pairs", [])
    before_only = match.get("before_only", [])
    after_only  = match.get("after_only", [])

    # STEP 경로 (ONLINE인 경우 _LIVE 폴더 우선 확인)
    # 1. _LIVE/{uid}/{uid}_before.stp 확인
    live_raw_dir = os.path.join(raw_dir, "_LIVE", uid)
    before_step = os.path.join(live_raw_dir, f"{uid}_before.stp")
    after_step  = os.path.join(live_raw_dir, f"{uid}_after.stp")
    
    # 2. 없으면 일반 raw 폴더 확인
    if not os.path.isfile(before_step):
        before_step = os.path.join(raw_dir, f"{uid}_before.stp")
        after_step  = os.path.join(raw_dir, f"{uid}_after.stp")

    if not os.path.isfile(before_step):
        safe_print(f"skip: before STEP not found -> {before_step}"); return
    if not os.path.isfile(after_step):
        safe_print(f"skip: after STEP not found -> {after_step}");  return

    safe_print(f"[{uid}] STEP loading ...")
    shapeB = load_step_shape(before_step)
    shapeA = load_step_shape(after_step)
    safe_print(f"[{uid}] STEP loaded")

    facesB = collect_faces(shapeB)
    facesA = collect_faces(shapeA)

    # 파라미터
    quick_small   = PARAMS["quick_delta_small_mm"]
    Nu, Nv        = PARAMS["fine_grid_u"], PARAMS["fine_grid_v"]
    patch_thr     = PARAMS["patch_delta_mm"]
    min_face_area = PARAMS["min_face_area_for_sampling"]
    min_comp_area = PARAMS["min_component_area_mm2"]

    out_pair_patches: List[Dict[str, Any]] = []

    # A) pair 처리
    safe_print(f"[{uid}] computing delta on pairs: {len(pairs)}")
    for p in pairs:
        ib = int(p["before_face_index"]); ia = int(p["after_face_index"])
        if not (0 <= ib < len(facesB) and 0 <= ia < len(facesA)):
            continue

        fb_info = Bfaces_info[ib]; fa_info = Afaces_info[ia]
        area_b = float(fb_info.get("area", 0.0))
        area_a = float(fa_info.get("area", 0.0))
        area_face = max(area_b, area_a)
        if area_face < min_face_area:
            out_pair_patches.append({
                "pair_id": int(p["pair_id"]),
                "before_face_index": ib, "after_face_index": ia,
                "has_change": False, "delta_quick_max": 0.0,
                "patches": [], "skipped_small_face": True,
            })
            continue

        face_b, face_a = facesB[ib], facesA[ia]
        try:
            umin_b, umax_b, vmin_b, vmax_b = breptools_UVBounds(face_b)
            umin_a, umax_a, vmin_a, vmax_a = breptools_UVBounds(face_a)
        except Exception:
            out_pair_patches.append({
                "pair_id": int(p["pair_id"]),
                "before_face_index": ib, "after_face_index": ia,
                "has_change": False, "delta_quick_max": 0.0,
                "patches": [], "uv_bounds_error": True,
            })
            continue
        if not (umax_b > umin_b and vmax_b > vmin_b and umax_a > umin_a and vmax_a > vmin_a):
            out_pair_patches.append({
                "pair_id": int(p["pair_id"]),
                "before_face_index": ib, "after_face_index": ia,
                "has_change": False, "delta_quick_max": 0.0,
                "patches": [], "degenerate_uv": True,
            })
            continue

        # 1) 빠른 샘플(중앙+모서리 5점)
        u_mid = 0.5*(umin_b+umax_b); v_mid = 0.5*(vmin_b+vmax_b)
        samples = [(u_mid, v_mid),(umin_b,vmin_b),(umin_b,vmax_b),(umax_b,vmin_b),(umax_b,vmax_b)]
        d_quick = compute_delta_normal(face_b, face_a, samples)
        dmax_q  = float(max(abs(x) for x in d_quick))
        if dmax_q < quick_small:
            out_pair_patches.append({
                "pair_id": int(p["pair_id"]),
                "before_face_index": ib, "after_face_index": ia,
                "has_change": False, "delta_quick_max": round(dmax_q,6),
                "patches": [],
            })
            continue

        # 2) 정밀 UV grid
        u_vals = np.linspace(umin_b, umax_b, Nu)
        v_vals = np.linspace(vmin_b, vmax_b, Nv)
        delta_grid = np.zeros((Nv, Nu), dtype=np.float64)
        for iv, v in enumerate(v_vals):
            for iu, u in enumerate(u_vals):
                delta_grid[iv, iu] = compute_delta_normal(face_b, face_a, [(u, v)])[0]

        mask = np.abs(delta_grid) >= patch_thr
        if not mask.any():
            out_pair_patches.append({
                "pair_id": int(p["pair_id"]),
                "before_face_index": ib, "after_face_index": ia,
                "has_change": False, "delta_quick_max": round(dmax_q,6),
                "patches": [],
            })
            continue

        labeled, nlab = _label_components_binary(mask.astype(bool))
        patches = []
        for lab in range(1, nlab+1):
            patch_mask = (labeled == lab)
            info_patch = summarize_patch(face_b, u_vals, v_vals, patch_mask, delta_grid, area_face)
            if info_patch is not None:
                info_patch["patch_id"] = len(patches)
                patches.append(info_patch)

        out_pair_patches.append({
            "pair_id": int(p["pair_id"]),
            "before_face_index": ib, "after_face_index": ia,
            "has_change": True, "delta_quick_max": round(dmax_q,6),
            "patches": patches,
        })

    # B) 신규/삭제 face 메타
    added_faces, removed_faces = [], []
    for ia in after_only:
        ia = int(ia)
        if 0 <= ia < len(Afaces_info):
            fa = Afaces_info[ia]
            ar = float(fa.get("area", 0.0))
            if ar >= min_comp_area:
                added_faces.append({
                    "face_index": ia,
                    "surf_type": fa["surf_type"],
                    "surf_type_code": int(fa.get("surf_type_code", 0)),
                    "area": float(round(ar,6)),
                    "bbox": {k:float(round(v,6)) for k,v in fa["bbox"].items()},
                    "center": [float(round(c,6)) for c in fa["center"]],
                    "normal_avg": [float(round(c,6)) for c in fa["normal_avg"]],
                    "bbox_diag": float(round(fa.get("bbox_diag", 0.0),6)),
                })
    for ib in before_only:
        ib = int(ib)
        if 0 <= ib < len(Bfaces_info):
            fb = Bfaces_info[ib]
            ar = float(fb.get("area", 0.0))
            if ar >= min_comp_area:
                removed_faces.append({
                    "face_index": ib,
                    "surf_type": fb["surf_type"],
                    "surf_type_code": int(fb.get("surf_type_code", 0)),
                    "area": float(round(ar,6)),
                    "bbox": {k:float(round(v,6)) for k,v in fb["bbox"].items()},
                    "center": [float(round(c,6)) for c in fb["center"]],
                    "normal_avg": [float(round(c,6)) for c in fb["normal_avg"]],
                    "bbox_diag": float(round(fb.get("bbox_diag", 0.0),6)),
                })

    # C) 저장
    result = {
        "uid": uid,
        "diag_mm": diag,
        "params": PARAMS,
        "pair_patches": out_pair_patches,
        "added_faces": added_faces,
        "removed_faces": removed_faces,
    }
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    safe_print(f"[{uid}] saved: {out_path}")
    safe_print(f"[{uid}] time: {time.time()-t0:.1f}s")

# ----------------- ONLINE RAW 준비 -----------------
def _prepare_live_raw(root: str, uid: str, before_path: str, after_path: str) -> str:
    raw_dir = os.path.join(root, "01_raw_L0")
    live_root = os.path.join(raw_dir, "_LIVE", uid)
    os.makedirs(live_root, exist_ok=True)
    
    dst_before = os.path.join(live_root, f"{uid}_before.stp")
    dst_after  = os.path.join(live_root, f"{uid}_after.stp")
    
    # [수정됨] SameFileError 방지
    try: shutil.copy2(before_path, dst_before)
    except shutil.SameFileError: pass
    except Exception as e: safe_print(f"[WARN] copy before failed: {e}")

    try: shutil.copy2(after_path, dst_after)
    except shutil.SameFileError: pass
    except Exception as e: safe_print(f"[WARN] copy after failed: {e}")
    
    return live_root

# ----------------- main -----------------
def main():
    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument("--root", default=None)     # BASE DIR override
    ap.add_argument("--uid", default=None)
    ap.add_argument("--before", default=None)
    ap.add_argument("--after",  default=None)
    ap.add_argument("--force",  action="store_true")
    # 호환용
    ap.add_argument("--uid_start", type=int, default=1)
    ap.add_argument("--uid_end",   type=int, default=14)
    args, _unknown = ap.parse_known_args()

    root = resolve_root(args.root)

    # 1) 온라인(1쌍) 모드
    if args.before and args.after:
        uid = args.uid if args.uid else "LIVE_001"
        # ONLINE용 RAW 준비 (필요 시 복사)
        _prepare_live_raw(root, uid, args.before, args.after)
        safe_print("===== 03S_FACE_UV_DIFF : ONLINE =====")
        safe_print(f"  UID={uid}")
        safe_print(f"  ROOT={root}")
        process_one_uid(root, uid, force=args.force)
        safe_print("===== 03S_FACE_UV_DIFF : ONLINE DONE =====")
        return

    # 2) 배치 모드
    safe_print("===== 03S_FACE_UV_DIFF : BATCH =====")
    st = max(1, int(args.uid_start))
    ed = max(st, int(args.uid_end))
    for i in range(st, ed+1):
        uid = f"UID_{i:03d}"
        try:
            process_one_uid(root, uid, force=args.force)
        except Exception as e:
            import traceback
            safe_print(f"exception on {uid}: {e}")
            traceback.print_exc()
    safe_print("===== 03S_FACE_UV_DIFF : BATCH DONE =====")

if __name__ == "__main__":
    main()