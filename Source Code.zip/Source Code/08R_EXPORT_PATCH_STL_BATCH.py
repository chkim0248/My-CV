# ================================================================
# 08R_EXPORT_PATCH_STL_BATCH.py  (FULL REPLACEMENT • Py38-safe)
#   - 기본: ONLINE (단일 before/after 페어 처리)
#   - 배치: --batch 플래그 명시 시에만 루프 실행
# ================================================================

import os, re, sys, csv, json, argparse, glob
from typing import List, Dict, Set, Tuple, Optional, Union

# ---------- ASCII-safe print ----------
def _s(x: object) -> str:
    return str(x).encode("ascii", "ignore").decode("ascii")
def _print(msg: object):
    print(_s(msg))

# ---------- Root resolver ----------
def pick_root_dir(default_local=r"C:\sf5\sfsdh3",
                  default_colab="/content/drive/MyDrive/sfsdh3") -> str:
    env_sf5 = os.getenv("SF5_ROOT", "").strip()
    if env_sf5 and os.path.isdir(env_sf5):
        return env_sf5
    if os.path.isdir("/content/drive/MyDrive") and os.path.isdir(default_colab):
        return default_colab
    return default_local

ROOT_DIR = pick_root_dir()
OUT_DIR_NAME = "08R_PATCH_STL"

def _env_float(k: str, default: float) -> float:
    try:
        return float(os.getenv(k, str(default)))
    except Exception:
        return default

def _env_int(k: str, default: int) -> int:
    try:
        return int(float(os.getenv(k, str(default))))
    except Exception:
        return default

def _env_bool(k: str, default: bool) -> bool:
    v = os.getenv(k, "")
    if v == "":
        return default
    return str(v).strip().lower() in ["1", "true", "yes", "y", "on"]

DELTA_THRESH = _env_float("SF8R_DELTA_THRESH", 0.05)
DEFLECT      = _env_float("SF8R_DEFLECT", 0.5)
UID_START    = _env_int("SF8R_UID_START", 1)
UID_END      = _env_int("SF8R_UID_END", 14)

USE_PAIR_PATCH   = _env_bool("SF8R_USE_PAIR",   True)
USE_ADDED_FACE   = _env_bool("SF8R_USE_ADDED",  True)
USE_REMOVED_FACE = _env_bool("SF8R_USE_REMOVED", False)

# ---------- UID helpers ----------
def _extract_uid_num(uid_raw: Optional[Union[str, int]]) -> Optional[int]:
    if uid_raw is None:
        return None
    s = str(uid_raw).strip()
    if s == "":
        return None
    if s.isdigit():
        return int(s)
    nums = re.findall(r"\d+", s)
    if nums:
        return int(nums[-1])
    try:
        return int(float(s))
    except Exception:
        return None

def _uid3(n: int) -> str:
    return f"{n:03d}"

def _norm_uid3(uid_raw: Optional[Union[str, int]], default_uid3: str = "151") -> str:
    n = _extract_uid_num(uid_raw)
    return _uid3(n) if n is not None else default_uid3

def _next_uid3(min_start: int = 151) -> str:
    pat = os.path.join(ROOT_DIR, "01_raw_L0", "UID_*_before.stp")
    nums: List[int] = []
    for p in glob.glob(pat):
        m = re.search(r"UID_(\d{3,})_before\.stp$", p.replace("\\", "/"))
        if m:
            try:
                nums.append(int(m.group(1)))
            except Exception:
                pass
    nxt = max(nums) + 1 if nums else min_start
    if nxt < min_start:
        nxt = min_start
    return _uid3(nxt)

# ---------- pythonocc-core ----------
try:
    from OCC.Core.STEPControl import STEPControl_Reader
    from OCC.Core.IFSelect import IFSelect_RetDone
    from OCC.Core.TopoDS import TopoDS_Shape, TopoDS_Compound, topods_Face
    from OCC.Core.TopExp import TopExp_Explorer
    from OCC.Core.TopAbs import TopAbs_FACE
    from OCC.Core.BRep import BRep_Builder
    from OCC.Core.BRepMesh import BRepMesh_IncrementalMesh
    from OCC.Core.StlAPI import StlAPI_Writer
except ImportError as e:
    _print("pythonocc-core import failed: " + str(e))
    _print("conda activate sdh_occ  ->  conda install -n sdh_occ -c conda-forge pythonocc-core")
    sys.exit(1)

# ---------- STEP/CSV I/O ----------
def load_step_shape(path: str) -> TopoDS_Shape:
    if not os.path.isfile(path):
        raise FileNotFoundError("STEP file not found: " + path)
    rdr = STEPControl_Reader()
    st = rdr.ReadFile(path)
    if st != IFSelect_RetDone:
        raise RuntimeError("STEP read failed: " + path)
    if rdr.TransferRoots() == 0:
        raise RuntimeError("STEP->Shape transfer failed: " + path)
    return rdr.OneShape()

def build_face_list(shape: TopoDS_Shape) -> List:
    faces: List = []
    exp = TopExp_Explorer(shape, TopAbs_FACE)
    while exp.More():
        faces.append(topods_Face(exp.Current()))
        exp.Next()
    return faces

def load_patch_features_csv(uid_raw: Optional[Union[str, int]]) -> List[Dict[str, str]]:
    if uid_raw is None:
        uid_raw = ""
    direct = os.path.join(ROOT_DIR, "04S_FACE_PATCH", str(uid_raw), f"{uid_raw}_PATCH_FEATURES.csv")
    if os.path.isfile(direct):
        csv_path = direct
    else:
        u3 = _norm_uid3(uid_raw, default_uid3="151")
        csv_path = os.path.join(ROOT_DIR, "04S_FACE_PATCH", f"UID_{u3}", f"UID_{u3}_PATCH_FEATURES.csv")
        if not os.path.isfile(csv_path):
            raise FileNotFoundError("PATCH_FEATURES CSV not found: " + csv_path)

    rows: List[Dict[str, str]] = []
    with open(csv_path, "r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for r in reader:
            rows.append(r)
    return rows

# ---------- patch face selection ----------
def _safe_int(v, d=-1):
    try: return int(v)
    except: return d

def _safe_float(v, d=0.0):
    try: return float(v)
    except: return d

def collect_changed_face_indices(
    rows: List[Dict[str, str]], delta_thresh: float
) -> Tuple[Set[int], Set[int]]:
    before_set, after_set = set(), set()
    for r in rows:
        ptype = str(r.get("patch_type", "")).strip()
        if not ptype:
            continue
        dmax = _safe_float(r.get("delta_max", "0.0"), 0.0)
        if delta_thresh > 0.0 and abs(dmax) < delta_thresh:
            continue
        b_idx = _safe_int(r.get("before_face_index", -1), -1)
        a_idx = _safe_int(r.get("after_face_index", -1), -1)

        if ptype == "pair_patch" and USE_PAIR_PATCH:
            if b_idx >= 0:
                before_set.add(b_idx)
            if a_idx >= 0:
                after_set.add(a_idx)
        elif ptype == "added_face" and USE_ADDED_FACE:
            if a_idx >= 0:
                after_set.add(a_idx)
        elif ptype == "removed_face" and USE_REMOVED_FACE:
            if b_idx >= 0:
                before_set.add(b_idx)
    return before_set, after_set

def make_compound_from_indices(face_list: List, index_set: Set[int]) -> TopoDS_Compound:
    builder = BRep_Builder()
    comp = TopoDS_Compound()
    builder.MakeCompound(comp)
    max_idx = len(face_list) - 1
    for i in sorted(index_set):
        if 0 <= i <= max_idx:
            builder.Add(comp, face_list[i])
        else:
            _print("warn: face index out of range: " + str(i))
    return comp

def export_compound_to_stl(compound: TopoDS_Compound, out_path: str, deflection: float):
    BRepMesh_IncrementalMesh(compound, deflection)
    writer = StlAPI_Writer()
    ok = writer.Write(compound, out_path)
    if not ok:
        raise RuntimeError("STL write failed: " + out_path)

# ---------- per-UID process ----------
def process_uid(uid3: str):
    _print(f"\n[UID_{uid3}] PATCH STL start")
    step_after = os.path.join(ROOT_DIR, "01_raw_L0", f"UID_{uid3}_after.stp")
    if not os.path.isfile(step_after):
        _print("  skip: missing AFTER STEP -> " + step_after)
        return

    rows = load_patch_features_csv(f"UID_{uid3}")
    _print("  patch rows = " + str(len(rows)))

    b_set, a_set = collect_changed_face_indices(rows, DELTA_THRESH)
    if len(b_set) == 0 and len(a_set) == 0:
        _print("  no faces by delta threshold -> fallback without threshold")
        b_set, a_set = collect_changed_face_indices(rows, 0.0)
        if len(b_set) == 0 and len(a_set) == 0:
            _print("  still empty -> SKIP")
            return

    shape_a = load_step_shape(step_after)
    faces_a = build_face_list(shape_a)
    comp_after = make_compound_from_indices(faces_a, a_set)

    out_dir = os.path.join(ROOT_DIR, OUT_DIR_NAME, f"UID_{uid3}")
    os.makedirs(out_dir, exist_ok=True)
    out_stl = os.path.join(out_dir, f"UID_{uid3}_PATCH.stl")
    export_compound_to_stl(comp_after, out_stl, DEFLECT)

    meta = {
        "uid": f"UID_{uid3}",
        "delta_thresh": DELTA_THRESH,
        "deflection": DEFLECT,
        "n_face_after": len(faces_a),
        "n_changed_after": len(a_set),
        "n_changed_before": len(b_set),
        "source_csv": f"04S_FACE_PATCH/UID_{uid3}/UID_{uid3}_PATCH_FEATURES.csv",
    }
    with open(os.path.join(out_dir, f"UID_{uid3}_PATCH_META.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)

    _print("  [SAVE] " + out_stl)
    _print("  done")

def process_uid_online(uid_raw: Optional[Union[str, int]], before_step: str, after_step: str):
    # UID 확정
    if uid_raw is None or str(uid_raw).strip() == "":
        u3 = _next_uid3(min_start=151)
        _print("ONLINE: auto assign UID_" + u3)
    else:
        u3 = _norm_uid3(uid_raw, default_uid3=_next_uid3(min_start=151))
        _print("ONLINE: use UID_" + u3)

    rows = load_patch_features_csv(uid_raw if uid_raw else f"UID_{u3}")
    _print("  patch rows = " + str(len(rows)))

    b_set, a_set = collect_changed_face_indices(rows, DELTA_THRESH)
    if len(b_set) == 0 and len(a_set) == 0:
        _print("  no faces by delta threshold -> fallback without threshold")
        b_set, a_set = collect_changed_face_indices(rows, 0.0)
        if len(b_set) == 0 and len(a_set) == 0:
            _print("  still empty -> SKIP")
            return

    shape_a = load_step_shape(after_step)
    faces_a = build_face_list(shape_a)
    comp_after = make_compound_from_indices(faces_a, a_set)

    out_dir = os.path.join(ROOT_DIR, OUT_DIR_NAME, f"UID_{u3}")
    os.makedirs(out_dir, exist_ok=True)
    out_stl = os.path.join(out_dir, f"UID_{u3}_PATCH.stl")
    export_compound_to_stl(comp_after, out_stl, DEFLECT)

    meta = {
        "uid": f"UID_{u3}",
        "delta_thresh": DELTA_THRESH,
        "deflection": DEFLECT,
        "n_face_after": len(faces_a),
        "n_changed_after": len(a_set),
        "n_changed_before": len(b_set),
        "source_hint": "LIVE or UID folder resolved",
    }
    with open(os.path.join(out_dir, f"UID_{u3}_PATCH_META.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)

    _print("  [SAVE] " + out_stl)
    _print("  ONLINE done")

# ---------- main ----------
def main():
    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument("--uid",    default=None)   # ONLINE: 선택
    ap.add_argument("--before", default=None)   # ONLINE: path
    ap.add_argument("--after",  default=None)   # ONLINE: path
    ap.add_argument("--batch",  action="store_true", help="명시 시에만 배치 실행")
    ap.add_argument("--uid_start", type=int, default=UID_START)
    ap.add_argument("--uid_end",   type=int, default=UID_END)
    ap.add_argument("--root",      default=None) # Root override
    args, _unknown = ap.parse_known_args()

    # 경로 재설정
    global ROOT_DIR
    if args.root:
        ROOT_DIR = os.path.abspath(args.root)

    _print("===== 08R_EXPORT_PATCH_STL_BATCH START =====")
    _print("ROOT_DIR      : " + ROOT_DIR)
    _print(f"DELTA_THRESH  : {DELTA_THRESH:.3f} mm")
    _print(f"DEFLECT       : {DEFLECT:.3f} mm")
    _print("OUT_DIR_NAME  : " + OUT_DIR_NAME)

    # 기본: ONLINE (before/after 필요)
    if not args.batch:
        if not args.before or not args.after:
            # 안전장치: 인자 없으면 경고 후 종료 (무한루프 방지)
            _print("[WARN] ONLINE mode requires --before and --after. Use --batch for loop.")
            return
        _print("MODE          : ONLINE (single pair)")
        process_uid_online(args.uid, args.before, args.after)
        _print("===== 08R PATCH ONLINE DONE =====")
        return

    # --batch 명시 시에만 배치
    _print("MODE          : BATCH (explicit)")
    _print(f"UID RANGE     : {args.uid_start:03d} ~ {args.uid_end:03d}")
    any_fail = False
    for n in range(int(args.uid_start), int(args.uid_end) + 1):
        u3 = _uid3(n)
        try:
            process_uid(u3)
        except Exception as e:
            any_fail = True
            _print(f"[ERROR] UID_{u3}: " + str(e))
    if any_fail:
        _print("DONE with errors (see logs)")
        sys.exit(2)
    _print("===== 08R_EXPORT_PATCH_STL_BATCH DONE =====")

if __name__ == "__main__":
    main()