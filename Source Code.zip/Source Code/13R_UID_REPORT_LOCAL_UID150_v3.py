# ============================================================
# 13R_UID_REPORT_LOCAL_UID150_v3.py  (FINAL SMART PATH FIX)
#
# 역할
#   - 11R(보정된 패치 데이터)을 로드하여 UID 단위 요약 리포트 생성
#   - [수정] 입력 파일 탐색 로직 개선 (지정된 파일 없으면 폴더 내 최신 파일 자동 선택)
#   - 기능: 상세 공정(설계/NC/방전 등) 집계 및 자연어 요약 생성
# ============================================================

import os
import re
import json
import glob
import argparse
import numpy as np
import pandas as pd
import warnings

warnings.filterwarnings("ignore")

# ---------- ASCII-safe print ----------
def _s(x: str) -> str:
    return str(x).encode("ascii", "ignore").decode("ascii")
def _print(msg: str):
    print(_s(msg))

# ---------- Root resolver ----------
def resolve_root(root_cli=None):
    if root_cli: return os.path.abspath(root_cli)
    env_root = os.environ.get("SF5_ROOT", "").strip()
    if env_root: return os.path.abspath(env_root)
    here = os.path.abspath(os.path.dirname(__file__))
    
    # 현재 위치에 11R 폴더가 있으면 거기가 루트
    if os.path.isdir(os.path.join(here, "11R_GROUND_TRUTH")):
        return here
    # 아니면 상위
    parent = os.path.abspath(os.path.join(here, ".."))
    if os.path.isdir(os.path.join(parent, "11R_GROUND_TRUTH")):
        return parent
    return here

ROOT_DIR = resolve_root()

# ---------- Helpers ----------
def safe_float(x):
    try:
        f = float(x)
        if np.isnan(f) or np.isinf(f): return 0.0
        return f
    except:
        return 0.0

def normalize_uid(x):
    s = str(x).strip()
    nums = re.findall(r"\d+", s)
    if nums:
        return f"UID_{int(nums[-1]):03d}"
    return "UID_000"

def find_input_csv_smart(base_dir, uid=None):
    """
    [핵심 수정] 11R 결과 파일을 스마트하게 탐색
    """
    gt_dir = os.path.join(base_dir, "11R_GROUND_TRUTH")
    
    # 1. 특정 UID 파일 우선
    if uid:
        nums = re.findall(r"\d+", str(uid))
        if nums:
            u_str = f"{int(nums[-1]):03d}"
            # 11R 결과
            cand = os.path.join(gt_dir, f"S_PATCH_TIME_COST_CALIB_UID{u_str}.csv")
            if os.path.exists(cand): return cand

    # 2. 배치 파일 또는 최신 파일 자동 탐색
    # UID 지정이 없거나 파일을 못 찾았을 때, 폴더 내의 CALIB 파일 중 가장 최신 것을 선택
    pattern = os.path.join(gt_dir, "S_PATCH_TIME_COST_CALIB_*.csv")
    files = glob.glob(pattern)
    
    if files:
        # 수정 시간 역순 정렬 (최신 파일이 0번)
        files.sort(key=os.path.getmtime, reverse=True)
        latest = files[0]
        _print(f"[13R] Auto-detected latest input: {os.path.basename(latest)}")
        return latest

    # 3. Fallback: 10R 예측 파일 (보정 전 데이터라도 리포트하기 위해)
    model_dir = os.path.join(base_dir, "10R_MODELS")
    if uid:
        nums = re.findall(r"\d+", str(uid))
        if nums:
            u_str = f"{int(nums[-1]):03d}"
            cand = os.path.join(model_dir, f"S_PATCH_WITH_TIME_COST_PRED_UID{u_str}.csv")
            if os.path.exists(cand): 
                _print(f"[13R] Fallback to 10R Pred: {os.path.basename(cand)}")
                return cand
            
    return None

# ---------- Main ----------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=None)
    ap.add_argument("--uid", default=None)
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--before", default=None)
    ap.add_argument("--after", default=None)
    args = ap.parse_args()

    global ROOT_DIR
    if args.root: ROOT_DIR = os.path.abspath(args.root)

    BASE = ROOT_DIR
    OUT_DIR = os.path.join(BASE, "13R_UID_REPORT")
    os.makedirs(OUT_DIR, exist_ok=True)

    _print("============================================")
    _print("===== 13R UID REPORT (SMART PATH FIX) =====")
    
    # 1. 입력 파일 찾기 (스마트 탐색)
    input_csv = find_input_csv_smart(BASE, args.uid)
    
    if not input_csv:
        _print("[13R][ERROR] 입력 데이터를 찾을 수 없습니다. (11R/10R 확인 필요)")
        # 파이프라인 연속성을 위해 빈 파일 생성
        dummy_df = pd.DataFrame(columns=["uid", "time_min_calib_uid", "cost_krw_calib_uid"])
        out_name = "S_UID_REPORT.csv"
        if args.uid: out_name = f"S_UID_REPORT_{args.uid}.csv"
        dummy_df.to_csv(os.path.join(OUT_DIR, out_name), index=False)
        return

    _print(f"[13R] Processing: {input_csv}")
    
    try:
        df = pd.read_csv(input_csv, encoding="utf-8-sig")
    except:
        df = pd.read_csv(input_csv, encoding="cp949")

    # 2. UID 정규화
    if "uid" not in df.columns:
        if args.uid:
            df["uid"] = args.uid
        else:
            if "UID" in df.columns: df["uid"] = df["UID"]
            else: df["uid"] = "UID_UNKNOWN"
            
    df["uid_norm"] = df["uid"].apply(normalize_uid)

    # 3. 값 채우기 (Fallback Logic)
    # Time
    df["time_final"] = 0.0
    if "time_min_calib" in df.columns:
        df["time_final"] = df["time_min_calib"].fillna(0)
    
    mask_zero = (df["time_final"] == 0)
    if "time_min_pred" in df.columns:
        df.loc[mask_zero, "time_final"] = df.loc[mask_zero, "time_min_pred"].fillna(0)
    
    mask_zero = (df["time_final"] == 0)
    if "time_min_auto" in df.columns:
        df.loc[mask_zero, "time_final"] = df.loc[mask_zero, "time_min_auto"].fillna(0)

    # Cost
    df["cost_final"] = 0.0
    if "cost_krw_calib" in df.columns:
        df["cost_final"] = df["cost_krw_calib"].fillna(0)
        
    mask_zero = (df["cost_final"] == 0)
    if "cost_krw_pred" in df.columns:
        df.loc[mask_zero, "cost_final"] = df.loc[mask_zero, "cost_krw_pred"].fillna(0)
        
    mask_zero = (df["cost_final"] == 0)
    if "cost_krw_auto" in df.columns:
        df.loc[mask_zero, "cost_final"] = df.loc[mask_zero, "cost_krw_auto"].fillna(0)

    df["time_final"] = pd.to_numeric(df["time_final"], errors='coerce').fillna(0.0)
    df["cost_final"] = pd.to_numeric(df["cost_final"], errors='coerce').fillna(0.0)

    # 보정 계수 역산 (상세 공정 배분용)
    if "time_min_auto" not in df.columns: df["time_min_auto"] = df["time_final"]
    
    def calc_scale(row):
        auto = safe_float(row.get("time_min_auto", 0))
        final = safe_float(row.get("time_final", 0))
        if auto <= 1e-6: return 1.0
        return final / auto

    df["calc_scale_factor"] = df.apply(calc_scale, axis=1)

    # 상세 공정값 계산
    detail_keys = ["design", "cnc", "edm", "elec", "polish", "weld", "etc"]
    
    for key in detail_keys:
        calib_col = f"time_{key}_calib"
        auto_col = f"time_{key}_auto"
        final_col = f"time_{key}_final"
        
        if calib_col in df.columns:
            df[final_col] = pd.to_numeric(df[calib_col], errors='coerce').fillna(0.0)
        elif auto_col in df.columns:
            df[final_col] = pd.to_numeric(df[auto_col], errors='coerce').fillna(0.0) * df["calc_scale_factor"]
        else:
            df[final_col] = 0.0

    # 4. 집계 (Aggregation)
    agg_dict = {
        "time_min_calib_uid": ("time_final", "sum"),
        "cost_krw_calib_uid": ("cost_final", "sum"),
        "n_patch": ("uid", "count"),
        "time_min_pred_uid": ("time_final", "sum"),
        "cost_krw_pred_uid": ("cost_final", "sum")
    }
    
    for key in detail_keys:
        agg_dict[f"time_{key}_sum"] = (f"time_{key}_final", "sum")

    report = df.groupby("uid_norm").agg(**agg_dict).reset_index()
    report.rename(columns={"uid_norm": "uid"}, inplace=True)

    # 5. 상세 공정 요약 텍스트 생성
    def make_breakdown_text(row):
        parts = []
        labels = {
            "design": "설계", "cnc": "NC가공", "edm": "방전", 
            "elec": "전극", "polish": "사상", "weld": "용접", "etc": "기타"
        }
        vals = []
        for key in detail_keys:
            val = row.get(f"time_{key}_sum", 0)
            if val > 1.0:
                vals.append((val, labels[key]))
        
        vals.sort(key=lambda x: x[0], reverse=True)
        for val, label in vals:
            parts.append(f"{label}: {int(val)}분")
        
        if not parts: return "상세 정보 없음"
        return ", ".join(parts)

    report["process_breakdown_ko"] = report.apply(make_breakdown_text, axis=1)

    # 6. Top-K 텍스트 생성
    def get_top_k_text(sub_df, sort_col, k=3):
        sub_df = sub_df.sort_values(sort_col, ascending=False).head(k)
        texts = []
        for _, row in sub_df.iterrows():
            pid = row.get("patch_global_id", row.get("patch_id", "?"))
            val = row[sort_col]
            why = str(row.get("why_total_ko", ""))
            if not why or why == "nan": why = str(row.get("why_geom_ko", "형상 변경"))
            why_short = why.split(".")[0][:30] + "..." if len(why) > 30 else why.split(".")[0]
            
            if "cost" in sort_col:
                texts.append(f"- 패치#{pid}: {int(val):,}원 ({why_short})")
            else:
                texts.append(f"- 패치#{pid}: {val:.1f}분 ({why_short})")
        return "\n".join(texts)

    top_time_list = []
    top_cost_list = []
    for uid in report["uid"]:
        sub = df[df["uid_norm"] == uid]
        top_time_list.append(get_top_k_text(sub, "time_final"))
        top_cost_list.append(get_top_k_text(sub, "cost_final"))

    report["top_patches_time_ko"] = top_time_list
    report["top_patches_cost_ko"] = top_cost_list
    
    # 7. 저장
    out_csv = os.path.join(OUT_DIR, "S_UID_REPORT.csv")
    
    if args.uid:
        single_out = os.path.join(OUT_DIR, f"S_UID_REPORT_{args.uid}.csv")
        report.to_csv(single_out, index=False, encoding="utf-8-sig")
        
        # 메인 리포트 업데이트
        if os.path.exists(out_csv):
            try:
                old_rep = pd.read_csv(out_csv, encoding="utf-8-sig")
                old_rep = old_rep[old_rep["uid"] != args.uid]
                report = pd.concat([old_rep, report], ignore_index=True)
            except: pass 

    report.to_csv(out_csv, index=False, encoding="utf-8-sig")
    
    _print(f"[13R] 리포트 생성 완료: {out_csv}")
    if not report.empty:
        # 로그에 샘플 출력
        print(f"      - 요약: {report.iloc[-1]['process_breakdown_ko']}")

if __name__ == "__main__":
    main()