# -*- coding: utf-8 -*-
# =============================================================================
# 10R_PATCH_LGBM_TRAIN_LOCAL_v3.py (FINAL PATH FIX + FULL INTEGRITY)
#
# [개요]
# 1. 17R에서 생성된 학습 데이터(S_PATCH_LABEL_UID.csv)를 로드하여 AI 모델 학습
# 2. 총 시간/비용 및 7대 세부 공정에 대한 개별 모델 학습
# 3. 범주형 데이터(Category) 메타데이터 저장으로 예측 시 오류 방지
#
# [수정 사항]
# - resolve_root 함수 수정: 무조건 상위로 가지 않고, 현재 위치에 데이터가 있으면 현재를 루트로 인식
# =============================================================================

import os
import sys
import glob
import json
import joblib
import argparse
import warnings
import traceback
import numpy as np
import pandas as pd
import lightgbm as lgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score

warnings.filterwarnings("ignore")

# -----------------------------------------------------------------------------
# 1. 유틸리티 및 설정
# -----------------------------------------------------------------------------
def _s(x: str) -> str:
    return str(x).encode("ascii", "ignore").decode("ascii")

def _print(msg: str):
    print(_s(msg))

def resolve_root(root_cli=None):
    """
    [핵심 수정] 실행 위치 기반 루트 경로 지능형 탐색
    """
    if root_cli: return os.path.abspath(root_cli)
    
    env_root = os.environ.get("SF5_ROOT", "").strip()
    if env_root: return os.path.abspath(env_root)
    
    here = os.path.abspath(os.path.dirname(__file__))
    
    # 1. 현재 위치에 17R_DATA 폴더가 있으면, 현재 위치가 ROOT임 (C:\sf5\sfsdh3)
    if os.path.isdir(os.path.join(here, "17R_DATA")):
        return here
        
    # 2. 없으면 상위 폴더 확인 (agent_core 내부에서 실행될 경우 등)
    parent = os.path.abspath(os.path.join(here, ".."))
    if os.path.isdir(os.path.join(parent, "17R_DATA")):
        return parent
        
    # 3. 그래도 없으면 현재 위치 반환 (경로 에러 확인 용이)
    return here

ROOT_DIR = resolve_root()

# -----------------------------------------------------------------------------
# 2. Feature & Target 정의
# -----------------------------------------------------------------------------
FEATURE_COLS = [
    "delta_max", "delta_avg", "area_est", 
    "bbox_x_span", "bbox_y_span", "bbox_z_span", 
    "bbox_xy_area", "bbox_xy_area_ratio",
    "normal_avg_z", "depth_ratio",
    "is_vertical_wall", 
    "geom_class_auto", "patch_type"
]

CAT_COLS = ["geom_class_auto", "patch_type"]

TARGETS = {
    "total_time": "time_min_measured",
    "total_cost": "cost_krw_measured",
    "design":     "time_design_measured",
    "cnc":        "time_cnc_measured",
    "edm":        "time_edm_measured",
    "elec":       "time_elec_measured",
    "polish":     "time_polish_measured",
    "weld":       "time_weld_measured",
    "etc":        "time_etc_measured"
}

# -----------------------------------------------------------------------------
# 3. 모델 학습 함수
# -----------------------------------------------------------------------------
def train_models(train_csv, model_dir):
    _print(f"[10R] Training Data Path: {train_csv}")
    
    if not os.path.exists(train_csv):
        # 경로 문제일 수 있으니 현재 위치 기준으로 다시 한번 확인
        alt_path = os.path.join(os.getcwd(), "17R_DATA", "S_PATCH_LABEL_UID.csv")
        if os.path.exists(alt_path):
            train_csv = alt_path
            _print(f"[10R] Found data at alt path: {train_csv}")
        else:
            raise FileNotFoundError(
                f"[CRITICAL] 학습 데이터가 없습니다: {train_csv}\n"
                " >> 먼저 '17R_UID150_AUG_GT_LOCAL.py'를 실행하여 데이터를 생성하십시오."
            )
    
    try:
        df = pd.read_csv(train_csv, encoding="utf-8-sig")
    except:
        try:
            df = pd.read_csv(train_csv, encoding="cp949")
        except Exception as e:
            raise ValueError(f"[CRITICAL] 데이터 로딩 실패: {e}")
            
    if df.empty:
        raise ValueError(f"[CRITICAL] 학습 데이터 파일이 비어 있습니다: {train_csv}")

    _print(f"      - Loaded Rows: {len(df)}")

    # Feature 컬럼 준비
    for c in FEATURE_COLS:
        if c not in df.columns:
            df[c] = 0.0

    # 범주형 데이터 처리 및 메타데이터 저장
    cat_meta = {}
    for c in CAT_COLS:
        if c in df.columns:
            df[c] = df[c].astype(str).astype("category")
            cat_meta[c] = df[c].cat.categories
            _print(f"      - Category '{c}': {len(cat_meta[c])} classes recorded.")
    
    meta_path = os.path.join(model_dir, "category_meta.pkl")
    joblib.dump(cat_meta, meta_path)
    _print(f"      [System] Category metadata saved to: {meta_path}")
    
    X = df[FEATURE_COLS]

    # 타겟별 모델 학습
    trained_count = 0
    for key, target_col in TARGETS.items():
        if target_col not in df.columns:
            _print(f"[WARN] Target '{target_col}' not found. Filling with 0.")
            df[target_col] = 0.0
            
        y = df[target_col].fillna(0.0)
        
        if len(df) > 20:
            X_train, X_valid, y_train, y_valid = train_test_split(X, y, test_size=0.2, random_state=42)
        else:
            X_train, X_valid, y_train, y_valid = X, X, y, y
        
        dtrain = lgb.Dataset(X_train, label=y_train)
        dvalid = lgb.Dataset(X_valid, label=y_valid)
        
        params = {
            "objective": "regression", "metric": "mae", 
            "verbosity": -1, "learning_rate": 0.05, 
            "num_leaves": 31, "feature_fraction": 0.9, 
            "bagging_fraction": 0.8, "bagging_freq": 5,
            "seed": 42
        }
        
        model = lgb.train(
            params, dtrain, num_boost_round=1000,
            valid_sets=[dtrain, dvalid],
            callbacks=[lgb.early_stopping(stopping_rounds=50, verbose=False)]
        )
        
        model_path = os.path.join(model_dir, f"model_{key}.pkl")
        joblib.dump(model, model_path)
        
        if len(y_valid) > 0:
            preds = model.predict(X_valid)
            mae = mean_absolute_error(y_valid, preds)
            _print(f"      [OK] Model '{key}' Saved. (Valid MAE: {mae:.2f})")
        else:
            _print(f"      [OK] Model '{key}' Saved. (No Validation Data)")
            
        trained_count += 1

    joblib.dump(FEATURE_COLS, os.path.join(model_dir, "feature_columns.pkl"))
    _print(f"[10R] All {trained_count} models trained successfully.")

# -----------------------------------------------------------------------------
# 4. 예측 함수
# -----------------------------------------------------------------------------
def predict_new(target_csv, model_dir, output_csv):
    _print(f"[10R] Predicting Target: {target_csv}")
    
    if not os.path.exists(target_csv):
        _print(f"[WARN] File not found: {target_csv}")
        return

    try:
        df = pd.read_csv(target_csv, encoding="utf-8-sig")
    except:
        df = pd.read_csv(target_csv, encoding="cp949")
        
    feat_path = os.path.join(model_dir, "feature_columns.pkl")
    cat_path  = os.path.join(model_dir, "category_meta.pkl")
    
    if not os.path.exists(feat_path) or not os.path.exists(cat_path):
        _print("[ERROR] Model metadata not found. Train first.")
        return
        
    use_feats = joblib.load(feat_path)
    cat_meta  = joblib.load(cat_path)
    
    for c in use_feats:
        if c not in df.columns: df[c] = 0.0

    for c in CAT_COLS:
        if c in df.columns and c in cat_meta:
            df[c] = df[c].astype(str).astype("category")
            df[c] = df[c].cat.set_categories(cat_meta[c])
            
    X = df[use_feats]
    
    for key, _ in TARGETS.items():
        model_path = os.path.join(model_dir, f"model_{key}.pkl")
        if not os.path.exists(model_path): continue
            
        try:
            model = joblib.load(model_path)
            preds = model.predict(X)
            preds = np.maximum(preds, 0.0)
            
            if key == "total_time": col = "time_min_pred"
            elif key == "total_cost": col = "cost_krw_pred"
            else: col = f"time_{key}_pred"
                
            df[col] = preds
        except Exception as e:
            _print(f"[WARN] Prediction failed for {key}: {e}")
            df[col] = 0.0
        
    df.to_csv(output_csv, index=False, encoding="utf-8-sig")
    _print(f"[10R] Saved: {output_csv}")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=None)
    parser.add_argument("--uid", default=None)
    parser.add_argument("--predict_csv", default=None) 
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--before", default=None)
    parser.add_argument("--after", default=None)
    args = parser.parse_args()

    global ROOT_DIR
    if args.root: ROOT_DIR = os.path.abspath(args.root)

    BASE = ROOT_DIR
    MODEL_DIR = os.path.join(BASE, "10R_MODELS")
    TRAIN_DATA = os.path.join(BASE, "17R_DATA", "S_PATCH_LABEL_UID.csv")
    
    os.makedirs(MODEL_DIR, exist_ok=True)

    _print("==================================================")
    _print("===== 10R PATCH LGBM TRAINER (V4 - PATH FIX) =====")
    _print(f"ROOT_DIR: {ROOT_DIR}")

    if not args.predict_csv or args.predict_csv == "TRAIN":
        try:
            train_models(TRAIN_DATA, MODEL_DIR)
        except Exception as e:
            _print(f"[ERROR] Training Failed: {e}")

    if args.predict_csv and args.predict_csv != "TRAIN":
        target_path = None
        output_path = None
        
        if args.predict_csv == "AUTO":
            if args.uid:
                import re
                nums = re.findall(r"\d+", str(args.uid))
                if nums:
                    u3 = f"{int(nums[-1]):03d}"
                    target_path = os.path.join(BASE, "07S_PATCH_LABEL", f"UID_{u3}_PATCH_LABEL_TEMPLATE.csv")
                    if not os.path.exists(target_path):
                         target_path = os.path.join(BASE, "07S_PATCH_LABEL", f"{args.uid}_PATCH_LABEL_TEMPLATE.csv")
                    output_path = os.path.join(MODEL_DIR, f"S_PATCH_WITH_TIME_COST_PRED_UID{u3}.csv")
            else:
                _print("[10R] AUTO prediction requires --uid argument.")
                return
        else:
            target_path = args.predict_csv
            base_name = os.path.basename(target_path).replace(".csv", "_PRED.csv")
            output_path = os.path.join(MODEL_DIR, base_name)

        if target_path and os.path.exists(target_path):
            predict_new(target_path, MODEL_DIR, output_path)
        elif target_path:
            _print(f"[WARN] Prediction target not found: {target_path}")

    _print("===== 10R DONE =====")

if __name__ == "__main__":
    main()