# -*- coding: utf-8 -*-
# =============================================================================
# 14R_AGENT_KB_EXPORT_LOCAL_UID150_v3.py (FINAL FULL INTEGRITY VERSION)
#
# [역할]
#   - 13R 결과(UID 요약, 상세공정)와 12R 결과(패치 상세, WHY)를 통합
#   - RAG 검색 엔진(15R)이 사용할 지식 베이스(KB) CSV 및 JSONL 생성
#
# [수정 핵심]
#   1. 경로 탐색 로직 강화 (FileNotFoundError 방지)
#   2. 상세 공정(Process Breakdown) 및 Top-K 정보를 텍스트에 필수 포함
#   3. 데이터 누락 시 안전한 Fallback 처리 (N/A 방지)
#   4. 코드 축약 없이 전체 로직 보존
# =============================================================================

import os
import json
import math
import argparse
import glob
import re
import numpy as np
import pandas as pd
import warnings

warnings.filterwarnings("ignore")

# -----------------------------------------------------------------------------
# 1. 환경 설정 및 유틸리티
# -----------------------------------------------------------------------------
def _s(x: str) -> str:
    return str(x).encode("ascii", "ignore").decode("ascii")

def _print(msg: str):
    print(_s(msg))

def resolve_root(root_cli=None):
    """
    [핵심 수정] 실행 위치 기반 루트 경로 지능형 탐색
    """
    if root_cli: return os.path.abspath(root_cli)
    
    env_root = os.environ.get("SF5_ROOT", "").strip()
    if env_root: return os.path.abspath(env_root)
    
    here = os.path.abspath(os.path.dirname(__file__))
    
    # 1. 현재 위치에 데이터 폴더가 있으면, 현재 위치가 ROOT
    if os.path.isdir(os.path.join(here, "14R_AGENT_KB")):
        return here
        
    # 2. 없으면 상위 폴더 확인
    parent = os.path.abspath(os.path.join(here, ".."))
    if os.path.isdir(os.path.join(parent, "14R_AGENT_KB")):
        return parent
        
    return here

ROOT_DIR = resolve_root()

# -----------------------------------------------------------------------------
# 2. 포맷팅 헬퍼 함수
# -----------------------------------------------------------------------------
def fmt_cost(val):
    try:
        v = float(val)
        if np.isnan(v) or np.isinf(v): return "0원"
        return f"{int(v):,}원"
    except:
        return "0원"

def fmt_time(val):
    try:
        v = float(val)
        if np.isnan(v) or np.isinf(v): return "0분"
        if v < 60:
            return f"{v:.1f}분"
        h = int(v // 60)
        m = int(v % 60)
        return f"{h}시간 {m}분"
    except:
        return "0분"

def safe_val(val, default=0):
    try:
        v = float(val)
        if np.isnan(v) or np.isinf(v): return default
        return v
    except:
        return default

# -----------------------------------------------------------------------------
# 3. 파일 탐색 로직 (스마트)
# -----------------------------------------------------------------------------
def find_uid_summary(base_dir, uid=None):
    """13R 결과 파일 찾기"""
    in_dir = os.path.join(base_dir, "13R_UID_REPORT")
    
    # 1. 특정 UID 파일 우선
    if uid:
        nums = re.findall(r"\d+", str(uid))
        if nums:
            u_str = f"{int(nums[-1]):03d}"
            cand = os.path.join(in_dir, f"S_UID_REPORT_UID_{u_str}.csv") # 이름 규칙 다양성 고려
            if not os.path.exists(cand):
                cand = os.path.join(in_dir, f"S_UID_REPORT_UID{u_str}.csv")
            if not os.path.exists(cand):
                cand = os.path.join(in_dir, f"S_UID_REPORT_{uid}.csv")
            
            if os.path.exists(cand): return cand

    # 2. 전체 파일 (Batch)
    cand = os.path.join(in_dir, "S_UID_REPORT.csv")
    if os.path.exists(cand): return cand
    
    return None

def find_patch_detail(base_dir, uid=None):
    """12R 결과 파일 찾기 (WHY 포함)"""
    in_dir = os.path.join(base_dir, "12R_RULEBOOK")
    
    # 1. 특정 UID 파일
    if uid:
        nums = re.findall(r"\d+", str(uid))
        if nums:
            u_str = f"{int(nums[-1]):03d}"
            cands = glob.glob(os.path.join(in_dir, f"*UID*{u_str}*.csv"))
            if cands: return cands[0]

    # 2. 전체 파일
    cand = os.path.join(in_dir, "S_PATCH_RULEBOOK_EXPLAIN.csv")
    if os.path.exists(cand): return cand
    
    # 3. Fallback: 11R 결과 (WHY는 없지만 수치는 있음)
    gt_dir = os.path.join(base_dir, "11R_GROUND_TRUTH")
    if uid:
        u_str = f"{int(nums[-1]):03d}"
        cands = glob.glob(os.path.join(gt_dir, f"*UID*{u_str}*.csv"))
        if cands: return cands[0]
        
    return None

# -----------------------------------------------------------------------------
# 4. 메인 처리 로직
# -----------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=None)
    ap.add_argument("--uid", default=None)
    # 파이프라인 호환용 더미 인자
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--before", default=None)
    ap.add_argument("--after", default=None)
    
    args = ap.parse_args()

    global ROOT_DIR
    if args.root:
        ROOT_DIR = os.path.abspath(args.root)

    BASE = ROOT_DIR
    OUT_DIR = os.path.join(BASE, "14R_AGENT_KB")
    os.makedirs(OUT_DIR, exist_ok=True)

    _print("==================================================")
    _print("===== 14R AGENT KB EXPORT (FULL INTEGRITY) =====")
    _print(f"ROOT: {BASE}")

    # 1. 파일 찾기
    uid_summary_path = find_uid_summary(BASE, args.uid)
    patch_detail_path = find_patch_detail(BASE, args.uid)
    
    _print(f"UID Summary : {os.path.basename(uid_summary_path) if uid_summary_path else 'Not Found'}")
    _print(f"Patch Detail: {os.path.basename(patch_detail_path) if patch_detail_path else 'Not Found'}")

    kb_rows = []

    # ---------------------------------------------------------
    # 2. UID 레벨 문서 생성 (요약 정보)
    # ---------------------------------------------------------
    if uid_summary_path:
        try:
            try: df_uid = pd.read_csv(uid_summary_path, encoding="utf-8-sig")
            except: df_uid = pd.read_csv(uid_summary_path, encoding="cp949")
            
            # 필터링
            if args.uid:
                target_str = str(int(re.findall(r"\d+", args.uid)[-1]))
                df_uid = df_uid[df_uid["uid"].astype(str).str.contains(target_str)]

            for _, row in df_uid.iterrows():
                uid = str(row.get("uid", "000"))
                
                # 수치 데이터
                t_calib = row.get("time_min_calib_uid", 0)
                c_calib = row.get("cost_krw_calib_uid", 0)
                n_patch = row.get("n_patch", 0)
                
                # [핵심] 상세 공정 내역 (13R에서 생성됨)
                breakdown = str(row.get("process_breakdown_ko", "상세 정보 없음"))
                if breakdown == "nan": breakdown = "상세 정보 없음"

                # [핵심] Top-K 패치 정보
                top_time = str(row.get("top_patches_time_ko", "")).replace("nan", "")
                top_cost = str(row.get("top_patches_cost_ko", "")).replace("nan", "")

                # 텍스트 생성 (RAG용)
                text_ko = f"""
[UID {uid} 설변 견적 요약]
1. 전체 개요
- 총 변경 패치: {int(safe_val(n_patch))}개
- 총 소요 시간: {fmt_time(t_calib)}
- 총 소요 비용: {fmt_cost(c_calib)}

2. 공정별 상세 내역 (Process Breakdown)
{breakdown}

3. 주요 비용 발생 원인 (Top Patches)
{top_cost}

4. 주요 시간 소요 원인 (Top Patches)
{top_time}
""".strip()

                meta = {
                    "uid": uid,
                    "level": "UID",
                    "time_val": safe_val(t_calib),
                    "cost_val": safe_val(c_calib),
                    "breakdown": breakdown
                }

                kb_rows.append({
                    "doc_id": f"{uid}_SUMMARY",
                    "uid": uid,
                    "level": "UID",
                    "text_ko": text_ko,
                    "meta_json": json.dumps(meta, ensure_ascii=False)
                })
                
        except Exception as e:
            _print(f"[14R][ERROR] UID Summary Processing Failed: {e}")

    # ---------------------------------------------------------
    # 3. Patch 레벨 문서 생성 (상세 정보)
    # ---------------------------------------------------------
    if patch_detail_path:
        try:
            try: df_patch = pd.read_csv(patch_detail_path, encoding="utf-8-sig")
            except: df_patch = pd.read_csv(patch_detail_path, encoding="cp949")

            # 필터링
            if args.uid:
                target_str = str(int(re.findall(r"\d+", args.uid)[-1]))
                df_patch = df_patch[df_patch["uid"].astype(str).str.contains(target_str)]

            for _, row in df_patch.iterrows():
                uid = str(row.get("uid", "000"))
                pid = row.get("patch_global_id", row.get("patch_id", "?"))
                
                # WHY Text (12R 결과)
                why = str(row.get("why_total_ko", ""))
                if not why or why == "nan":
                    # 12R 결과가 없으면 기본 정보로 생성
                    geom = str(row.get("geom_class_auto", "-"))
                    proc = str(row.get("process_family_auto", "-"))
                    why = f"형상: {geom}, 공정: {proc}"

                # 수치 (11R 보정값 우선, 없으면 예측값)
                t_val = row.get("time_min_calib", row.get("time_min_pred", 0))
                c_val = row.get("cost_krw_calib", row.get("cost_krw_pred", 0))
                
                # 공정 정보
                proc_fam = str(row.get("process_family_auto", "기타"))
                machine = str(row.get("machine_group_auto", "-"))

                text_ko = f"""
[UID {uid} 패치 #{pid} 상세 분석]
- 공정: {proc_fam} ({machine})
- 시간: {fmt_time(t_val)}
- 비용: {fmt_cost(c_val)}

[분석 근거]
{why}
""".strip()

                meta = {
                    "uid": uid,
                    "level": "PATCH",
                    "patch_id": str(pid),
                    "process": proc_fam,
                    "machine": machine,
                    "time_val": safe_val(t_val),
                    "cost_val": safe_val(c_val)
                }

                kb_rows.append({
                    "doc_id": f"{uid}_PATCH_{pid}",
                    "uid": uid,
                    "level": "PATCH",
                    "text_ko": text_ko,
                    "meta_json": json.dumps(meta, ensure_ascii=False)
                })

        except Exception as e:
            _print(f"[14R][ERROR] Patch Detail Processing Failed: {e}")

    # ---------------------------------------------------------
    # 4. 저장 (Save & Merge)
    # ---------------------------------------------------------
    if not kb_rows:
        _print("[14R][WARN] No KB data generated.")
        # 파이프라인 유지를 위해 빈 파일이라도 생성
        if not os.path.exists(os.path.join(OUT_DIR, "S_AGENT_KNOWLEDGE_RAG.csv")):
            pd.DataFrame(columns=["doc_id","uid","level","text_ko","meta_json"]).to_csv(
                os.path.join(OUT_DIR, "S_AGENT_KNOWLEDGE_RAG.csv"), index=False, encoding="utf-8-sig"
            )
        return

    df_kb = pd.DataFrame(kb_rows)
    out_csv = os.path.join(OUT_DIR, "S_AGENT_KNOWLEDGE_RAG.csv")
    
    # 기존 데이터와 병합 (Batch Update Logic)
    # Online 모드에서는 해당 UID만 갱신, 나머지는 유지
    if os.path.exists(out_csv):
        try:
            df_old = pd.read_csv(out_csv, encoding="utf-8-sig")
            
            # 이번에 처리한 UID들은 기존 데이터에서 제거 (덮어쓰기 위해)
            new_uids = df_kb["uid"].unique().astype(str)
            df_old = df_old[~df_old["uid"].astype(str).isin(new_uids)]
            
            df_kb = pd.concat([df_old, df_kb], ignore_index=True)
        except Exception as e:
            _print(f"[14R][WARN] Failed to merge with existing KB: {e}")
            # 병합 실패 시 새 데이터로만 덮어쓰기 (안전책)

    df_kb.to_csv(out_csv, index=False, encoding="utf-8-sig")
    
    # JSONL 저장 (백업용)
    out_jsonl = os.path.join(OUT_DIR, "S_AGENT_KNOWLEDGE_RAG.jsonl")
    df_kb.to_json(out_jsonl, orient="records", lines=True, force_ascii=False)

    _print(f"[14R] KB Generated: {out_csv} ({len(df_kb)} docs)")

if __name__ == "__main__":
    main()