# ============================================================
# 06S_PATCH_FILTER_EXPORT.py  (ONLINE/BATCH COMPATIBLE • 완전 교체판)
#
# Role
#   - Load: 05S_PATCH_DATA/S_PATCH_FEATURES_ALL_UIDS.csv
#   - Filter small/noisy patches
#   - Save:
#       1) 06S_PATCH_FILTER/S_PATCH_FEATURES_FILTERED.csv
#       2) 06S_PATCH_FILTER/S_PATCH_FOR_LABEL.csv
#       3) 06S_PATCH_FILTER/S_PATCH_STATS.txt
#
# Modes
#   - ONLINE (one UID):  python 06S_PATCH_FILTER_EXPORT.py --uid UID_151
#   - BATCH  (all UID):  python 06S_PATCH_FILTER_EXPORT.py
# ============================================================

import os
import re
import csv
import math
import argparse
from collections import defaultdict, Counter

# ----------------- 경로 리졸버 -----------------
def resolve_root(root_cli=None):
    if root_cli: return os.path.abspath(root_cli)
    env_root = os.environ.get("SF5_ROOT", "").strip()
    if env_root: return os.path.abspath(env_root)
    here = os.path.abspath(os.path.dirname(__file__))
    return os.path.abspath(os.path.join(here, ".."))

ROOT_DIR = resolve_root()

PATCH_DATA_DIR = os.path.join(ROOT_DIR, "05S_PATCH_DATA")
PATCH_DATA_CSV = os.path.join(PATCH_DATA_DIR, "S_PATCH_FEATURES_ALL_UIDS.csv")

OUT_DIR = os.path.join(ROOT_DIR, "06S_PATCH_FILTER")
os.makedirs(OUT_DIR, exist_ok=True)

OUT_FILTERED_CSV  = os.path.join(OUT_DIR, "S_PATCH_FEATURES_FILTERED.csv")
OUT_FOR_LABEL_CSV = os.path.join(OUT_DIR, "S_PATCH_FOR_LABEL.csv")
OUT_STATS_TXT     = os.path.join(OUT_DIR, "S_PATCH_STATS.txt")

# ----------------- 필터 기준 -----------------
def _env_float(key, default):
    try:
        v = float(os.getenv(key, str(default)))
        if math.isfinite(v):
            return v
    except Exception:
        pass
    return default

MIN_ABS_DELTA_MAX = _env_float("SF6_MIN_ABS_DELTA_MAX", 0.05)
MIN_AREA_EST      = _env_float("SF6_MIN_AREA_EST",      5.0)

TARGET_UIDS = None

# ----------------- 유틸 -----------------
def to_float(val, default=0.0):
    try:
        v = float(val)
        return v if math.isfinite(v) else default
    except Exception:
        return default

def extract_uid_num(x):
    if x is None: return None
    s = str(x).strip()
    if s == "": return None
    # 숫자만 있으면 바로 반환
    if s.isdigit(): return int(s)
    # UID_151 -> 151
    nums = re.findall(r"\d+", s)
    if nums: return int(nums[-1])
    return None

def normalize_uid(row):
    cand = None
    for k in ["UID", "uid", "uid_num", "source_uid", "source_uid_num"]:
        if k in row and str(row[k]).strip() != "":
            cand = row[k]
            break
    uid_num = extract_uid_num(cand)
    if uid_num is None:
        return None, None
    return uid_num, f"{uid_num:03d}"

def union_headers(rows):
    keys = []
    seen = set()
    for r in rows:
        for k in r.keys():
            if k not in seen:
                keys.append(k); seen.add(k)
    front = [c for c in ["UID_norm", "uid_num", "UID", "uid"] if c in seen]
    rest  = [c for c in keys if c not in front]
    return front + rest

# ----------------- LOAD -----------------
def load_all_patches(csv_path):
    if not os.path.isfile(csv_path):
        raise FileNotFoundError("[ERROR] input CSV not found: " + csv_path)

    rows = []
    bad_uid = 0
    with open(csv_path, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            raise RuntimeError("[ERROR] CSV header not found")
        for row in reader:
            uid_num, uid_norm = normalize_uid(row)
            if uid_norm is None:
                bad_uid += 1
                continue
            row["uid_num"]  = uid_num
            row["UID_norm"] = uid_norm
            rows.append(row)
    print(f"[LOAD] rows: {len(rows)} (skip bad UID: {bad_uid})")
    return rows

# ----------------- FILTER & STATS -----------------
def filter_and_collect(rows):
    filtered_rows = []
    stats_uid = Counter()
    stats_uid_type = defaultdict(Counter)

    drop_by_delta = 0
    drop_by_area  = 0

    for row in rows:
        uid = row.get("UID_norm", "")
        # TARGET_UIDS가 설정되어 있으면 해당 UID만 통과
        if TARGET_UIDS is not None and uid not in TARGET_UIDS:
            continue

        patch_type = row.get("patch_type", "UNKNOWN")
        delta_max  = to_float(row.get("delta_max", "0"))
        area_est   = to_float(row.get("area_est", "0"))

        if abs(delta_max) < MIN_ABS_DELTA_MAX:
            drop_by_delta += 1
            continue
        if area_est < MIN_AREA_EST:
            drop_by_area += 1
            continue

        filtered_rows.append(row)
        stats_uid[uid] += 1
        stats_uid_type[uid][patch_type] += 1

    print(f"[FILTER] kept: {len(filtered_rows)}")
    print(f"[FILTER] drop delta: {drop_by_delta}")
    print(f"[FILTER] drop area : {drop_by_area}")
    return filtered_rows, stats_uid, stats_uid_type

# ----------------- SAVE -----------------
def _append_or_write_csv(rows, out_path, dedup_subset=None):
    if not rows:
        print("[WARN] no rows -> skip saving:", os.path.basename(out_path))
        return
    try:
        import pandas as pd
    except Exception as e:
        raise RuntimeError("pandas required for 06S save: " + str(e))

    df_new = pd.DataFrame(rows)
    
    # 기존 파일 있으면 로드 후 병합
    if os.path.isfile(out_path):
        try:
            df_old = pd.read_csv(out_path, encoding="utf-8-sig")
        except:
            df_old = pd.read_csv(out_path, encoding="cp949")
            
        # TARGET_UIDS 모드라면, 기존 데이터에서 해당 UID 제거 후 append (덮어쓰기 효과)
        if TARGET_UIDS:
            if "UID_norm" in df_old.columns:
                df_old = df_old[~df_old["UID_norm"].isin(TARGET_UIDS)]
            elif "uid" in df_old.columns:
                # 간단 문자열 매칭 시도
                df_old = df_old[~df_old["uid"].astype(str).str.contains("|".join(TARGET_UIDS))]

        df_all = pd.concat([df_old, df_new], ignore_index=True, sort=False)
    else:
        df_all = df_new

    # 중복 제거
    if dedup_subset:
        ex = [c for c in dedup_subset if c in df_all.columns]
        if ex:
            df_all = df_all.drop_duplicates(subset=ex, keep='last')
        else:
            df_all = df_all.drop_duplicates(keep='last')
    else:
        df_all = df_all.drop_duplicates(keep='last')

    tmp = out_path + ".tmp"
    df_all.to_csv(tmp, index=False, encoding="utf-8-sig")
    try:
        os.replace(tmp, out_path)
    except OSError:
        if os.path.exists(out_path):
            os.remove(out_path)
        os.rename(tmp, out_path)
    print("[SAVE]", out_path)

def save_filtered_csv(rows):
    dedup_cols = ["patch_global_id"]
    _append_or_write_csv(rows, OUT_FILTERED_CSV, dedup_subset=dedup_cols)

def save_for_label_csv(rows):
    DEFAULT_LABEL_COLS = [
        "UID_norm","uid_num","UID","uid",
        "patch_global_id","patch_type",
        "pair_id","before_face_index","after_face_index",
        "surf_type_before","surf_type_after",
        "surf_type_code_before","surf_type_code_after",
        "delta_avg","delta_max","delta_min",
        "abs_delta_max","abs_delta_avg",
        "area_est","sign","delta_dir",
        "normal_avg_x","normal_avg_y","normal_avg_z",
        "normal_main_axis","is_visible_zplus","side_hint",
        "center_x","center_y","center_z",
        "bbox_x_span","bbox_y_span","bbox_z_span",
        "bbox_xy_area","bbox_xy_area_ratio",
        "face_area_before","face_area_after",
        "diag_mm",
        "time_min_auto","cost_krw_auto",
        "pred_time_min","pred_cost_krw","why"
    ]
    header = union_headers(rows)
    label_cols = [c for c in DEFAULT_LABEL_COLS if c in header]

    slim = [{c: r.get(c, "") for c in label_cols} for r in rows]
    dedup_cols = ["patch_global_id"]
    _append_or_write_csv(slim, OUT_FOR_LABEL_CSV, dedup_subset=dedup_cols)

def save_stats(stats_uid, stats_uid_type):
    lines = []
    lines.append("===== 06S PATCH FILTER STATS =====")
    lines.append(f"MIN_ABS_DELTA_MAX = {MIN_ABS_DELTA_MAX}")
    lines.append(f"MIN_AREA_EST      = {MIN_AREA_EST}")
    if TARGET_UIDS:
        lines.append("TARGET_UIDS = " + ", ".join(sorted(TARGET_UIDS)))
    else:
        lines.append("TARGET_UIDS = ALL")
    
    total = sum(stats_uid.values())
    lines.append(f"TOTAL KEPT = {total}")
    for uid in sorted(stats_uid.keys()):
        cnt = stats_uid[uid]
        lines.append(f"[UID {uid}] count = {cnt}")
        for t, n in stats_uid_type[uid].items():
            lines.append(f"  - {t}: {n}")

    # 통계 파일은 덮어쓰기 (온라인 모드에서는 통계 의미가 약해지므로 단순 로그용)
    with open(OUT_STATS_TXT, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print("[SAVE]", OUT_STATS_TXT)

# ----------------- MAIN -----------------
def _uid3_or_none(uid_in: str):
    num = extract_uid_num(uid_in)
    if num is None: return None
    return f"{num:03d}"

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--uid", default=None, help="one UID (e.g., 151)")
    parser.add_argument("--root", default=None)
    # pipeline compat
    parser.add_argument("--before", default=None)
    parser.add_argument("--after",  default=None)
    args, _ = parser.parse_known_args()

    global ROOT_DIR, PATCH_DATA_DIR, PATCH_DATA_CSV, OUT_DIR, OUT_FILTERED_CSV, OUT_FOR_LABEL_CSV, OUT_STATS_TXT, TARGET_UIDS
    
    if args.root:
        ROOT_DIR = resolve_root(args.root)
        # 경로 재설정
        PATCH_DATA_DIR = os.path.join(ROOT_DIR, "05S_PATCH_DATA")
        PATCH_DATA_CSV = os.path.join(PATCH_DATA_DIR, "S_PATCH_FEATURES_ALL_UIDS.csv")
        OUT_DIR = os.path.join(ROOT_DIR, "06S_PATCH_FILTER")
        os.makedirs(OUT_DIR, exist_ok=True)
        OUT_FILTERED_CSV  = os.path.join(OUT_DIR, "S_PATCH_FEATURES_FILTERED.csv")
        OUT_FOR_LABEL_CSV = os.path.join(OUT_DIR, "S_PATCH_FOR_LABEL.csv")
        OUT_STATS_TXT     = os.path.join(OUT_DIR, "S_PATCH_STATS.txt")

    if args.uid:
        u3 = _uid3_or_none(args.uid)
        if u3 is None:
            raise RuntimeError(f"[06S] failed to parse uid from: {args.uid}")
        TARGET_UIDS = [u3]
        print("===== 06S ONLINE =====")
    else:
        print("===== 06S BATCH =====")

    print("ROOT_DIR          :", ROOT_DIR)
    
    rows = load_all_patches(PATCH_DATA_CSV)
    filtered_rows, stats_uid, stats_uid_type = filter_and_collect(rows)

    save_filtered_csv(filtered_rows)
    save_for_label_csv(filtered_rows)
    save_stats(stats_uid, stats_uid_type)

    print("===== 06S DONE =====")

if __name__ == "__main__":
    main()