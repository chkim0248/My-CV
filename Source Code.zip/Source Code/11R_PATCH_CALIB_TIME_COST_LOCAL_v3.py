# ============================================================
# 11R_PATCH_CALIB_TIME_COST_LOCAL_v3.py  (FINAL PATH FIX)
#
# 역할
#   - 10R 예측값(Predicted)과 17R 실측값(GT)을 비교하여 보정(Calibration) 수행
#   - [수정] resolve_root 함수: 무조건 상위로 가지 않고, 현재 위치에 폴더가 있으면 거기를 루트로 사용
#   - 기능: 총합 보정 비율(Scale)을 산출하여 상세 공정(Detail) 값에도 동일 적용
# ============================================================

import os
import sys
import glob
import json
import argparse
import re
import numpy as np
import pandas as pd
import warnings

warnings.filterwarnings("ignore")

# ---------- ASCII-safe print ----------
def _s(x: str) -> str:
    return str(x).encode("ascii", "ignore").decode("ascii")
def _print(msg: str):
    print(_s(msg))

# ---------- Root resolver (경로 수정됨) ----------
def resolve_root(root_cli=None):
    """
    [핵심 수정] 무조건 ..로 가지 않고, 현재 위치에 데이터 폴더가 있는지 확인
    """
    if root_cli: return os.path.abspath(root_cli)
    
    env_root = os.environ.get("SF5_ROOT", "").strip()
    if env_root: return os.path.abspath(env_root)
    
    here = os.path.abspath(os.path.dirname(__file__))
    
    # 1. 현재 위치가 루트인지 확인 (11R_GROUND_TRUTH 폴더가 있는지)
    if os.path.isdir(os.path.join(here, "11R_GROUND_TRUTH")):
        return here
        
    # 2. 아니면 상위 폴더 확인 (agent_core 등 하위 폴더에서 실행된 경우)
    parent = os.path.abspath(os.path.join(here, ".."))
    if os.path.isdir(os.path.join(parent, "11R_GROUND_TRUTH")):
        return parent
        
    # 3. 그래도 없으면 현재 위치 반환 (최소한 엉뚱한 상위로 가진 않음)
    return here

ROOT_DIR = resolve_root()

# ----------------- 유틸 -----------------
def safe_num(s):
    return pd.to_numeric(s, errors="coerce").fillna(0.0)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=None)
    parser.add_argument("--uid", default=None)
    parser.add_argument("--pred_csv", default=None) # AUTO or path
    # pipeline compat
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--before", default=None)
    parser.add_argument("--after", default=None)
    
    args = parser.parse_args()

    global ROOT_DIR
    if args.root:
        ROOT_DIR = os.path.abspath(args.root)

    BASE = ROOT_DIR
    MODEL_DIR = os.path.join(BASE, "10R_MODELS")
    GT_CSV    = os.path.join(BASE, "17R_DATA", "S_UID_GT.csv")
    OUT_DIR   = os.path.join(BASE, "11R_GROUND_TRUTH")
    os.makedirs(OUT_DIR, exist_ok=True)

    _print("============================================")
    _print("===== 11R PATCH CALIBRATION (PATH FIX) =====")
    _print(f"ROOT_DIR: {BASE}")

    # 1. 입력 예측 파일 찾기 (10R 결과)
    target_pred_csv = None
    
    if args.pred_csv and args.pred_csv != "AUTO":
        target_pred_csv = args.pred_csv
    elif args.uid:
        # Online Mode
        nums = re.findall(r"\d+", str(args.uid))
        if nums:
            u3 = f"{int(nums[-1]):03d}"
            target_pred_csv = os.path.join(MODEL_DIR, f"S_PATCH_WITH_TIME_COST_PRED_UID{u3}.csv")
    else:
        _print("[11R][WARN] No UID specified. Skipping.")
        return

    if not target_pred_csv or not os.path.exists(target_pred_csv):
        _print(f"[11R][WARN] Prediction file not found: {target_pred_csv}")
        return

    _print(f"[11R] Loading Prediction: {target_pred_csv}")
    try:
        df_pred = pd.read_csv(target_pred_csv, encoding="utf-8-sig")
    except:
        df_pred = pd.read_csv(target_pred_csv, encoding="cp949")

    # 2. GT(실측) 로드
    df_gt = pd.DataFrame()
    if os.path.exists(GT_CSV):
        try:
            df_gt = pd.read_csv(GT_CSV, encoding="utf-8-sig")
        except:
            df_gt = pd.read_csv(GT_CSV, encoding="cp949")
            
    # GT 정규화
    if not df_gt.empty and "uid" in df_gt.columns:
        df_gt["uid_str"] = df_gt["uid"].astype(str).apply(
            lambda x: str(int(re.findall(r"\d+", x)[-1])) if re.findall(r"\d+", x) else ""
        )
    
    # 3. 보정 (Calibration) 수행
    # 현재 파일의 UID 확인
    current_uid_num = "000"
    
    if "uid" not in df_pred.columns:
        # 파일명에서 추론
        u_match = re.search(r"UID(\d+)", os.path.basename(target_pred_csv))
        if u_match:
            current_uid_num = str(int(u_match.group(1)))
    else:
        # 첫 번째 행의 UID 사용
        val = str(df_pred["uid"].iloc[0])
        nums = re.findall(r"\d+", val)
        if nums:
            current_uid_num = str(int(nums[-1]))

    # GT 매칭
    time_scale = 1.0
    cost_scale = 1.0
    has_gt = False
    
    if not df_gt.empty:
        gt_row = df_gt[df_gt["uid_str"] == current_uid_num]
        
        if not gt_row.empty:
            t_real = float(gt_row["time_min_measured"].iloc[0])
            c_real = float(gt_row["cost_krw_measured"].iloc[0])
            
            # 예측 총합
            t_pred_sum = safe_num(df_pred.get("time_min_pred", 0)).sum()
            c_pred_sum = safe_num(df_pred.get("cost_krw_pred", 0)).sum()
            
            if t_pred_sum > 0: time_scale = t_real / t_pred_sum
            if c_pred_sum > 0: cost_scale = c_real / c_pred_sum
            
            has_gt = True
            _print(f"      [GT MATCH] UID_{current_uid_num}")
            _print(f"      - Time Scale: {time_scale:.4f} (Real {t_real:.1f} / Pred {t_pred_sum:.1f})")
            _print(f"      - Cost Scale: {cost_scale:.4f}")
        else:
            _print(f"      [GT MISS] No GT for UID_{current_uid_num}. Using Scale=1.0")

    # 4. 상세 공정 보정 (Detail Calibration)
    detail_keys = ["design", "cnc", "edm", "elec", "polish", "weld", "etc"]
    
    # (A) 총량 보정
    df_pred["time_min_calib"] = safe_num(df_pred.get("time_min_pred", 0)) * time_scale
    df_pred["cost_krw_calib"] = safe_num(df_pred.get("cost_krw_pred", 0)) * cost_scale
    
    # (B) 상세 보정
    for key in detail_keys:
        pred_col = f"time_{key}_pred"
        calib_col = f"time_{key}_calib"
        
        if pred_col in df_pred.columns:
            df_pred[calib_col] = safe_num(df_pred[pred_col]) * time_scale
        else:
            df_pred[calib_col] = 0.0

    # 메타 정보
    df_pred["time_scale_uid"] = time_scale
    df_pred["cost_scale_uid"] = cost_scale
    df_pred["has_gt"] = has_gt

    # 5. 저장
    out_name = f"S_PATCH_TIME_COST_CALIB_UID{current_uid_num}.csv"
    out_path = os.path.join(OUT_DIR, out_name)
    
    df_pred.to_csv(out_path, index=False, encoding="utf-8-sig")
    _print(f"[11R] Saved Calibration: {out_path}")

    _print("===== 11R DONE =====")

if __name__ == "__main__":
    main()