# -*- coding: utf-8 -*-
# =============================================================================
# 17R_UID150_AUG_GT_LOCAL.py (FINAL FULL EXPERT VERSION)
#
# [개요]
# 1. 공정 실측값(GT) 엑셀을 로드하여 시스템 표준 데이터로 변환
# 2. 07S에서 산출된 "공정별 비중(Ratio)"을 기준으로, 실측 총액(Total)을 "상세 공정 실측값"으로 역배분(Reverse Distribute)
# 3. 이를 기반으로 500개 증강 데이터를 생성하여 학습용(Label) 데이터 구축
#
# [수정 사항]
# - 시간 단위 변환 (*60) 로직 제거 (입력값 그대로 사용)
# - 상세 공정(설계/NC/방전/전극/사상/기타)에 대한 Measured 컬럼 생성 로직 추가
# =============================================================================

import os
import re
import json
import math
import argparse
import warnings
import sys
import subprocess
import random
import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

# -----------------------------------------------------------------------------
# 1. 유틸리티 및 설정
# -----------------------------------------------------------------------------
def _s(x: str) -> str:
    return str(x).encode("ascii", "ignore").decode("ascii")

def aprint(msg: str):
    print(_s(msg))

def _ensure_openpyxl():
    try:
        import openpyxl
    except ImportError:
        aprint("[17R] 'openpyxl' 라이브러리 미설치 감지 -> 자동 설치 중...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "openpyxl"])
        aprint("[17R] openpyxl 설치 완료.")

def resolve_root(root_cli=None):
    if root_cli: return os.path.abspath(root_cli)
    env_root = os.environ.get("SF5_ROOT", "").strip()
    if env_root: return os.path.abspath(env_root)
    return os.path.dirname(os.path.abspath(__file__))

ROOT_DIR = resolve_root()

def ensure_dir(p):
    os.makedirs(p, exist_ok=True)
    return p

def ensure_uid_str(x):
    if pd.isna(x): return None
    s = str(x).strip()
    # 숫자만 추출하여 003 형식으로 변환
    s_clean = s.replace("UID_", "").replace("uid_", "")
    m = re.search(r"\d+", s_clean)
    if not m: return None
    return f"{int(float(m.group())):03d}"

def pick_uid_col(df):
    for c in ["uid", "UID", "uid_str", "UID_str", "uid_num", "UID_num"]:
        if c in df.columns: return c
    return None

def safe_num(s):
    return pd.to_numeric(s, errors="coerce").fillna(0.0)

# -----------------------------------------------------------------------------
# 2. 메인 로직
# -----------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base_dir", default=None)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--max_uid", type=int, default=500)
    ap.add_argument("--overwrite", action="store_true")
    args = ap.parse_args()

    global ROOT_DIR
    if args.base_dir:
        ROOT_DIR = os.path.abspath(args.base_dir)

    BASE = ROOT_DIR
    DIR_07S   = os.path.join(BASE, "07S_PATCH_LABEL")
    INPUT_07S = os.path.join(DIR_07S, "S_PATCH_LABEL_TEMPLATE.csv")
    EXCEL_GT  = os.path.join(BASE, "11R_GROUND_TRUTH", "공정_실측값.xlsx")

    OUT_DIR   = ensure_dir(os.path.join(BASE, "17R_DATA"))
    OUT_PATCH_ALIAS = os.path.join(OUT_DIR, "S_PATCH_LABEL_UID.csv") # 학습용
    OUT_UIDGT_ALIAS = os.path.join(OUT_DIR, "S_UID_GT.csv")          # RAG용

    aprint("========================================================")
    aprint("===== 17R DATA AUGMENTATION & REVERSE DISTRIBUTION =====")
    aprint("========================================================")

    # ---------------------------------------------------------
    # 1. 07S 결과 로드 (Estimates & Ratios Source)
    # ---------------------------------------------------------
    if not os.path.exists(INPUT_07S):
        raise FileNotFoundError(f"[17R] 07S result not found: {INPUT_07S}")
    
    # 인코딩 대응
    try:
        df_patch = pd.read_csv(INPUT_07S, encoding="utf-8-sig")
    except:
        df_patch = pd.read_csv(INPUT_07S, encoding="cp949")
    
    # UID 정규화
    uid_col_07s = pick_uid_col(df_patch)
    if not uid_col_07s: raise KeyError("[17R] UID column not found in 07S CSV")
    
    df_patch["uid"] = df_patch[uid_col_07s].apply(ensure_uid_str)
    df_patch = df_patch[df_patch["uid"].notna()].copy()
    
    # 07S에서 생성된 상세 공정 컬럼 확인
    # (없으면 0으로 채워서라도 진행)
    DETAIL_COLS_TIME = [
        "time_design_auto", "time_cnc_auto", "time_edm_auto", 
        "time_elec_auto", "time_polish_auto", "time_weld_auto", "time_etc_auto"
    ]
    for c in DETAIL_COLS_TIME:
        if c not in df_patch.columns:
            df_patch[c] = 0.0

    # ---------------------------------------------------------
    # 2. 엑셀 실측값(GT) 로드 및 정제
    # ---------------------------------------------------------
    if not os.path.exists(EXCEL_GT):
        raise FileNotFoundError(f"[17R] GT Excel not found: {EXCEL_GT}")
    
    _ensure_openpyxl()
    xls = pd.read_excel(EXCEL_GT, sheet_name=None)
    
    # 시트 자동 탐색 (가장 그럴듯한 시트 선정)
    df_gt_raw = None
    max_score = -1
    
    for name, df in xls.items():
        score = 0
        cols_lower = [str(c).lower() for c in df.columns]
        if any("uid" in c for c in cols_lower): score += 5
        if any("time" in c or "시간" in c or "분" in c for c in cols_lower): score += 3
        if any("cost" in c or "비용" in c or "금액" in c for c in cols_lower): score += 3
        
        if score > max_score:
            max_score = score
            df_gt_raw = df
            
    if df_gt_raw is None:
        df_gt_raw = list(xls.values())[0]

    # 컬럼 매핑
    uid_gt_col = time_gt_col = cost_gt_col = None
    for c in df_gt_raw.columns:
        lc = str(c).lower()
        if not uid_gt_col and "uid" in lc: uid_gt_col = c
        elif not time_gt_col and ("time" in lc or "시간" in lc or "분" in lc): time_gt_col = c
        elif not cost_gt_col and ("cost" in lc or "비용" in lc or "금액" in lc): cost_gt_col = c
    
    if not (uid_gt_col and time_gt_col):
        # 매핑 실패 시 강제 할당 (A열, B열, C열)
        cols = df_gt_raw.columns
        uid_gt_col = cols[0]
        time_gt_col = cols[1] if len(cols) > 1 else cols[0]
        cost_gt_col = cols[2] if len(cols) > 2 else cols[1]

    # 표준화된 GT DataFrame 생성
    df_gt = pd.DataFrame()
    df_gt["uid_raw"] = df_gt_raw[uid_gt_col]
    df_gt["time_val"] = df_gt_raw[time_gt_col]
    df_gt["cost_val"] = df_gt_raw[cost_gt_col] if cost_gt_col else 0.0
    
    df_gt["uid"] = df_gt["uid_raw"].apply(ensure_uid_str)
    
    # [핵심 수정] 단위 변환 로직 제거 (입력값을 분(Minute)으로 신뢰)
    df_gt["time_min_measured"] = safe_num(df_gt["time_val"])
    df_gt["cost_krw_measured"] = safe_num(df_gt["cost_val"])
    
    # 유효 데이터만 필터링
    df_gt = df_gt[df_gt["uid"].notna()].drop_duplicates("uid")
    # 값이 0인 데이터도 살려둠 (0분일 수도 있으므로), 단 NaN은 0으로 처리됨
    
    real_uids = sorted(df_gt["uid"].unique())
    aprint(f"[17R] Loaded GT: {len(df_gt)} rows. Target UIDs: {real_uids}")

    # ---------------------------------------------------------
    # 3. 역배분 (Reverse Distribution) 및 데이터 준비
    # ---------------------------------------------------------
    final_patches = []
    final_gt_rows = []
    
    rng = np.random.default_rng(args.seed)

    # (A) Real Data Processing (Calibration)
    for u in real_uids:
        # 해당 UID의 패치들 가져오기
        patches = df_patch[df_patch["uid"] == u].copy()
        
        # 07S에 해당 UID 패치가 없으면 스킵 (매칭 실패)
        if patches.empty: 
            # GT는 있는데 패치가 없는 경우 -> 학습 데이터 생성 불가
            continue
        
        # 해당 UID의 실측 총합
        gt_row = df_gt[df_gt["uid"] == u].iloc[0]
        total_time_gt = float(gt_row["time_min_measured"])
        total_cost_gt = float(gt_row["cost_krw_measured"])
        
        # 07S 예측 총합 (Scale 계산용)
        # 상세 공정 시간의 합계로 전체 시간 계산
        # (기존 time_min_auto를 써도 되지만, 상세 합계가 더 정확할 수 있음)
        total_time_est = sum([safe_num(patches[c]).sum() for c in DETAIL_COLS_TIME])
        # 혹시 0이면 1.0으로 방어
        if total_time_est <= 0: total_time_est = 1.0
        
        total_cost_est = safe_num(patches["cost_krw_auto"]).sum()
        if total_cost_est <= 0: total_cost_est = 1.0
        
        # 스케일 팩터 (Calibration Factor)
        scale_time = total_time_gt / total_time_est
        scale_cost = total_cost_gt / total_cost_est
        
        # [역배분 로직]
        # 예측된 각 상세 시간(auto)에 scale을 곱해서 -> 실측 상세 시간(measured) 추정치 생성
        for col in DETAIL_COLS_TIME:
            # ex: time_design_auto -> time_design_measured
            meas_col = col.replace("_auto", "_measured")
            patches[meas_col] = safe_num(patches[col]) * scale_time
            
        # 비용은 전체 비율로 배분 (상세 비용 컬럼 부재 시)
        patches["cost_krw_measured"] = safe_num(patches["cost_krw_auto"]) * scale_cost
        
        # Total Measured (학습 타겟 검증용)
        patches["time_min_measured"] = patches[[c.replace("_auto", "_measured") for c in DETAIL_COLS_TIME]].sum(axis=1)
        
        # 식별자 부여
        patches["uid_kind"] = "real"
        
        final_patches.append(patches)
        final_gt_rows.append(gt_row.to_dict())

    # (B) Augmentation (Data Generation)
    # 15번부터 max_uid까지 가상 데이터 생성
    if final_patches:
        src_df = pd.concat(final_patches)
        
        # 증강 시작 번호 (기존 번호 다음부터)
        last_real_num = int(real_uids[-1])
        start_aug_num = max(15, last_real_num + 1)
        
        for new_num in range(start_aug_num, args.max_uid + 1):
            new_uid = f"{new_num:03d}"
            
            # 랜덤하게 원본 UID 하나 선택 (Template)
            src_uid = rng.choice(real_uids)
            src_sub = src_df[src_df["uid"] == src_uid].copy()
            
            if src_sub.empty: continue

            # 패치 샘플링 (개수 변형: 80% ~ 120%)
            n_sample = int(len(src_sub) * rng.uniform(0.8, 1.2))
            n_sample = max(1, n_sample)
            
            aug_sub = src_sub.sample(n=n_sample, replace=True).copy()
            aug_sub["uid"] = new_uid
            aug_sub["uid_kind"] = "aug"
            
            # 전체적인 난이도 스케일 (0.7배 ~ 1.5배) - 현장 변수 시뮬레이션
            global_scale = rng.uniform(0.7, 1.5)
            
            # 값 변형 (노이즈 추가)
            # 형상 피처 + 상세 공정값 + 비용 모두 변형
            cols_to_noise = ["delta_max", "area_est"] + DETAIL_COLS_TIME + ["cost_krw_auto", "cost_krw_measured"]
            # measured 컬럼들도 변형 대상에 포함
            for col in DETAIL_COLS_TIME:
                cols_to_noise.append(col.replace("_auto", "_measured"))

            for col in cols_to_noise:
                if col in aug_sub.columns:
                    val = safe_num(aug_sub[col])
                    # 개별 노이즈 +/- 10% * 글로벌 스케일
                    noise = rng.uniform(0.9, 1.1, size=len(val))
                    aug_sub[col] = val * noise * global_scale
            
            # 합계 재계산 (변형된 상세값 합산)
            measured_cols = [c.replace("_auto", "_measured") for c in DETAIL_COLS_TIME]
            aug_sub["time_min_measured"] = aug_sub[measured_cols].sum(axis=1)

            final_patches.append(aug_sub)
            
            # GT Row 생성 (UID별 합계)
            t_sum = aug_sub["time_min_measured"].sum()
            c_sum = aug_sub["cost_krw_measured"].sum()
            
            final_gt_rows.append({
                "uid": new_uid,
                "time_min_measured": t_sum,
                "cost_krw_measured": c_sum,
                "uid_kind": "aug"
            })

    # ---------------------------------------------------------
    # 4. 저장 (Merge & Save)
    # ---------------------------------------------------------
    if final_patches:
        df_all = pd.concat(final_patches, ignore_index=True)
        df_gt_all = pd.DataFrame(final_gt_rows)
        
        # 파일 저장
        df_all.to_csv(OUT_PATCH_ALIAS, index=False, encoding="utf-8-sig")
        df_gt_all.to_csv(OUT_UIDGT_ALIAS, index=False, encoding="utf-8-sig")
        
        aprint(f"[17R] DONE.")
        aprint(f"      - Total Patches: {len(df_all)}")
        aprint(f"      - Total UIDs   : {len(df_gt_all)}")
        aprint(f"      - Patch Output : {OUT_PATCH_ALIAS}")
        aprint(f"      - GT Output    : {OUT_UIDGT_ALIAS}")
        
    else:
        aprint("[17R][ERROR] No data generated. Check 07S input or GT Excel.")

if __name__ == "__main__":
    main()