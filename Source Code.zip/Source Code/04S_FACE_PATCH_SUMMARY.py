# ============================================================
# 04S_FACE_PATCH_SUMMARY.py  (ONLINE/BATCH COMPATIBLE • 완전 교체판)
# - Input : 01S_FACE_SCAN/<uid>/*_FACE_INFO.json, 03S_FACE_UV_DIFF/<uid>/*_UV_DIFF.json
# - Output: 04S_FACE_PATCH/<uid>/<uid>_PATCH_FEATURES.csv
# - Usage :
#     Single : python 04S_FACE_PATCH_SUMMARY.py --uid UID_151 [--force]
#     Batch  : python 04S_FACE_PATCH_SUMMARY.py
# ============================================================

import os
import sys
import json
import csv
import time
import argparse
from typing import List, Dict, Any, Optional, Tuple

# ----------------- 경로 리졸버 -----------------
def resolve_root(root_cli=None):
    if root_cli: return os.path.abspath(root_cli)
    env_root = os.environ.get("SF5_ROOT", "").strip()
    if env_root: return os.path.abspath(env_root)
    here = os.path.abspath(os.path.dirname(__file__))
    return os.path.abspath(os.path.join(here, ".."))

BASE_DIR     = resolve_root()
SCAN_DIR     = os.path.join(BASE_DIR, "01S_FACE_SCAN")
UV_DIFF_DIR  = os.path.join(BASE_DIR, "03S_FACE_UV_DIFF")
OUT_BASE_DIR = os.path.join(BASE_DIR, "04S_FACE_PATCH")
os.makedirs(OUT_BASE_DIR, exist_ok=True)

UID_LIST = [f"UID_{i:03d}" for i in range(1, 15)]

# ----------------- utils -----------------
def safe_get(d: Dict[str, Any], key: str, default=None):
    return d[key] if isinstance(d, dict) and (key in d) else default

def load_json(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def ensure_dir(path: str):
    if not os.path.isdir(path):
        os.makedirs(path, exist_ok=True)

def to_float(x, default=None):
    try:
        if x is None:
            return default
        return float(x)
    except Exception:
        return default

def extract_normal_any(patch: Dict[str, Any],
                       fb_info: Optional[Dict[str, Any]],
                       fa_info: Optional[Dict[str, Any]]) -> Optional[Tuple[float, float, float]]:
    cand = ["normal_avg", "normal_3d", "normal", "avg_normal"]
    for k in cand:
        v = patch.get(k, None)
        if isinstance(v, list) and len(v) == 3:
            nx, ny, nz = to_float(v[0]), to_float(v[1]), to_float(v[2])
            if nx is not None and ny is not None and nz is not None:
                return (nx, ny, nz)
    for info in [fb_info, fa_info]:
        if isinstance(info, dict):
            for k in cand:
                v = info.get(k, None)
                if isinstance(v, list) and len(v) == 3:
                    nx, ny, nz = to_float(v[0]), to_float(v[1]), to_float(v[2])
                    if nx is not None and ny is not None and nz is not None:
                        return (nx, ny, nz)
    return None

def normalize_delta_dir(patch_type: str, sign_val, delta_avg):
    if patch_type == "added_face":
        return "thicker"
    if patch_type == "removed_face":
        return "thinner"
    s = str(sign_val).lower() if sign_val is not None else ""
    da = to_float(delta_avg, 0.0)
    if any(t in s for t in ["thicker", "add", "plus", "positive", "new"]):
        return "thicker"
    if any(t in s for t in ["thinner", "remove", "minus", "negative", "deleted"]):
        return "thinner"
    if any(t in s for t in ["mixed", "both"]):
        return "mixed"
    if da > 1e-6:
        return "thicker"
    if da < -1e-6:
        return "thinner"
    return "zero"

def main_axis_from_normal(nx, ny, nz):
    if nx is None or ny is None or nz is None:
        return None
    ax = abs(nx); ay = abs(ny); az = abs(nz)
    if   ax >= ay and ax >= az: return "X"
    elif ay >= ax and ay >= az: return "Y"
    else: return "Z"

def visible_zplus_from_normal(nz, thr=0.3):
    if nz is None: return None
    return 1 if nz >= thr else 0

def side_hint_from_normal(nz, thr=0.3):
    if nz is None: return "UNKNOWN"
    if nz >=  thr: return "CAVITY"
    if nz <= -thr: return "CORE"
    return "SIDE"

def bbox_spans(bbox: Dict[str, Any]):
    if not isinstance(bbox, dict):
        return (None, None, None, None, None)
    xmin = to_float(bbox.get("xmin")); xmax = to_float(bbox.get("xmax"))
    ymin = to_float(bbox.get("ymin")); ymax = to_float(bbox.get("ymax"))
    zmin = to_float(bbox.get("zmin")); zmax = to_float(bbox.get("zmax"))
    if None in (xmin, xmax, ymin, ymax, zmin, zmax):
        return (None, None, None, None, None)
    sx = max(0.0, xmax - xmin)
    sy = max(0.0, ymax - ymin)
    sz = max(0.0, zmax - zmin)
    xy_area = sx * sy
    denom = xy_area + (sz * sz) + 1e-9
    xy_ratio = xy_area / denom
    return (sx, sy, sz, xy_area, xy_ratio)

def _norm_uid(u: str) -> str:
    if u is None:
        return None
    u = str(u).strip()
    if u.isdigit():
        return f"UID_{int(u):03d}"
    if u.startswith("UID_"):
        return u
    return u  # LIVE_***

# ----------------- core -----------------
def process_one_uid(uid: str, *, force: bool = False):
    print("\n==================================================")
    print(f"[{uid}] 04S_FACE_PATCH_SUMMARY start")

    # BASE_DIR 재확인 (전역 변수 의존성 제거)
    scan_dir_local = os.path.join(BASE_DIR, "01S_FACE_SCAN")
    uv_dir_local   = os.path.join(BASE_DIR, "03S_FACE_UV_DIFF")
    out_dir_local  = os.path.join(BASE_DIR, "04S_FACE_PATCH")

    scan_dir  = os.path.join(scan_dir_local, uid)
    uv_dir    = os.path.join(uv_dir_local, uid)

    scan_path = os.path.join(scan_dir, f"{uid}_FACE_INFO.json")
    uv_path   = os.path.join(uv_dir,   f"{uid}_UV_DIFF.json")

    if not os.path.isfile(scan_path):
        print(f"  missing FACE_INFO.json -> skip: {scan_path}")
        return
    if not os.path.isfile(uv_path):
        print(f"  missing UV_DIFF.json -> skip: {uv_path}")
        return

    out_uid_dir  = os.path.join(out_dir_local, uid); ensure_dir(out_uid_dir)
    summary_path = os.path.join(out_uid_dir, f"{uid}_PATCH_SUMMARY.json")
    csv_path     = os.path.join(out_uid_dir, f"{uid}_PATCH_FEATURES.csv")

    env_force = os.environ.get("SF5_FORCE_REBUILD", "0") == "1"
    if os.path.isfile(csv_path) and not (force or env_force):
        print(f"[{uid}] reuse existing CSV: {csv_path}")
        return

    print("  FACE_INFO :", scan_path)
    print("  UV_DIFF   :", uv_path)
    print("  SUMMARY   :", summary_path)
    print("  CSV       :", csv_path, " (overwrite)")
    t0 = time.time()

    info    = load_json(scan_path)
    uv_diff = load_json(uv_path)

    diag_mm = float(safe_get(info, "diag_mm", safe_get(uv_diff, "diag_mm", 1.0)) or 1.0)

    before_faces_info = safe_get(info, "before", {}).get("faces", [])
    after_faces_info  = safe_get(info, "after",  {}).get("faces", [])
    pair_patches  = safe_get(uv_diff, "pair_patches", [])
    added_faces   = safe_get(uv_diff, "added_faces", [])
    removed_faces = safe_get(uv_diff, "removed_faces", [])
    params_03S    = safe_get(uv_diff, "params", {})

    fieldnames = [
        "uid","patch_global_id","patch_type",
        "pair_id","before_face_index","after_face_index",
        "surf_type_before","surf_type_after","surf_type_code_before","surf_type_code_after",
        "delta_avg","delta_max","delta_min","n_samples","area_est","sign",
        "delta_dir","abs_delta_max","abs_delta_avg",
        "normal_avg_x","normal_avg_y","normal_avg_z","normal_main_axis","is_visible_zplus","side_hint",
        "center_x","center_y","center_z",
        "bbox_xmin","bbox_ymin","bbox_zmin","bbox_xmax","bbox_ymax","bbox_zmax",
        "bbox_x_span","bbox_y_span","bbox_z_span","bbox_xy_area","bbox_xy_area_ratio",
        "face_area_before","face_area_after","diag_mm",
    ]

    rows: List[Dict[str, Any]] = []
    patch_global_id = 0
    n_pair_with_change = 0
    n_pair_patch_records = 0

    # A. pair patches
    for pair in pair_patches:
        has_change = bool(safe_get(pair, "has_change", False))
        ib = safe_get(pair, "before_face_index", None)
        ia = safe_get(pair, "after_face_index",  None)
        if not has_change:
            continue
        patches = safe_get(pair, "patches", [])
        if not patches:
            continue
        n_pair_with_change += 1

        fb = before_faces_info[ib] if (isinstance(ib, int) and 0 <= ib < len(before_faces_info)) else None
        fa = after_faces_info[ia]  if (isinstance(ia, int) and 0 <= ia < len(after_faces_info))  else None
        area_b = float(fb["area"]) if (fb and ("area" in fb)) else None
        area_a = float(fa["area"]) if (fa and ("area" in fa)) else None

        for patch in patches:
            row = {k: None for k in fieldnames}
            row["uid"]             = uid
            row["patch_global_id"] = patch_global_id
            row["patch_type"]      = "pair_patch"
            row["pair_id"]            = safe_get(pair, "pair_id", None)
            row["before_face_index"]  = ib
            row["after_face_index"]   = ia
            row["surf_type_before"]      = safe_get(fb, "surf_type") if fb else None
            row["surf_type_after"]       = safe_get(fa, "surf_type") if fa else None
            row["surf_type_code_before"] = safe_get(fb, "surf_type_code") if fb else None
            row["surf_type_code_after"]  = safe_get(fa, "surf_type_code") if fa else None

            da  = safe_get(patch, "delta_avg", None)
            dmx = safe_get(patch, "delta_max", None)
            dmn = safe_get(patch, "delta_min", None)

            row["delta_avg"] = da
            row["delta_max"] = dmx
            row["delta_min"] = dmn
            row["n_samples"] = safe_get(patch, "n_samples", None)
            row["area_est"]  = safe_get(patch, "area_est",  None)
            row["sign"]      = safe_get(patch, "sign",      None)

            row["delta_dir"]     = normalize_delta_dir("pair_patch", row["sign"], da)
            row["abs_delta_max"] = abs(to_float(dmx, 0.0)) if dmx is not None else None
            row["abs_delta_avg"] = abs(to_float(da,  0.0)) if da  is not None else None

            nrm = extract_normal_any(patch, fb, fa)
            if nrm is not None:
                nx, ny, nz = nrm
                row["normal_avg_x"] = nx
                row["normal_avg_y"] = ny
                row["normal_avg_z"] = nz
                row["normal_main_axis"] = main_axis_from_normal(nx, ny, nz)
                row["is_visible_zplus"] = visible_zplus_from_normal(nz)
                row["side_hint"]        = side_hint_from_normal(nz)
            else:
                row["normal_main_axis"] = None
                row["is_visible_zplus"] = None
                row["side_hint"]        = "UNKNOWN"

            center = safe_get(patch, "center_3d", None)
            if isinstance(center, list) and len(center) == 3:
                row["center_x"], row["center_y"], row["center_z"] = center[0], center[1], center[2]

            bbox = safe_get(patch, "bbox_3d", None)
            if isinstance(bbox, dict):
                row["bbox_xmin"] = bbox.get("xmin", None)
                row["bbox_ymin"] = bbox.get("ymin", None)
                row["bbox_zmin"] = bbox.get("zmin", None)
                row["bbox_xmax"] = bbox.get("xmax", None)
                row["bbox_ymax"] = bbox.get("ymax", None)
                row["bbox_zmax"] = bbox.get("zmax", None)
                sx, sy, sz, xy_area, xy_ratio = bbox_spans(bbox)
                row["bbox_x_span"] = sx
                row["bbox_y_span"] = sy
                row["bbox_z_span"] = sz
                row["bbox_xy_area"] = xy_area
                row["bbox_xy_area_ratio"] = xy_ratio

            row["face_area_before"] = area_b
            row["face_area_after"]  = area_a
            row["diag_mm"]          = diag_mm

            rows.append(row)
            patch_global_id += 1
            n_pair_patch_records += 1

    # B. added_faces
    n_added_records = 0
    for fa in added_faces:
        ia = safe_get(fa, "face_index", None)
        fa_info = after_faces_info[ia] if (isinstance(ia, int) and 0 <= ia < len(after_faces_info)) else None
        area = to_float(safe_get(fa, "area", safe_get(fa_info, "area"))) if (fa_info or ("area" in fa)) else None

        row = {k: None for k in fieldnames}
        row["uid"]             = uid
        row["patch_global_id"] = patch_global_id
        row["patch_type"]      = "added_face"
        row["pair_id"]            = None
        row["before_face_index"]  = None
        row["after_face_index"]   = ia

        row["surf_type_before"]      = None
        row["surf_type_after"]       = safe_get(fa, "surf_type", safe_get(fa_info, "surf_type"))
        row["surf_type_code_before"] = None
        row["surf_type_code_after"]  = safe_get(fa, "surf_type_code", safe_get(fa_info, "surf_type_code"))

        row["delta_avg"] = 0.0
        row["delta_max"] = 0.0
        row["delta_min"] = 0.0
        row["n_samples"] = None
        row["area_est"]  = area
        row["sign"]      = "new"

        row["delta_dir"]     = normalize_delta_dir("added_face", row["sign"], 0.0)
        row["abs_delta_max"] = 0.0
        row["abs_delta_avg"] = 0.0

        nrm = extract_normal_any(fa, None, fa_info)
        if nrm is not None:
            nx, ny, nz = nrm
            row["normal_avg_x"] = nx
            row["normal_avg_y"] = ny
            row["normal_avg_z"] = nz
            row["normal_main_axis"] = main_axis_from_normal(nx, ny, nz)
            row["is_visible_zplus"] = visible_zplus_from_normal(nz)
            row["side_hint"]        = side_hint_from_normal(nz)
        else:
            row["normal_main_axis"] = None
            row["is_visible_zplus"] = None
            row["side_hint"]        = "UNKNOWN"

        center = safe_get(fa, "center", safe_get(fa_info, "center"))
        if isinstance(center, list) and len(center) == 3:
            row["center_x"], row["center_y"], row["center_z"] = center[0], center[1], center[2]

        bbox = safe_get(fa, "bbox", safe_get(fa_info, "bbox"))
        if isinstance(bbox, dict):
            row["bbox_xmin"] = bbox.get("xmin", None)
            row["bbox_ymin"] = bbox.get("ymin", None)
            row["bbox_zmin"] = bbox.get("zmin", None)
            row["bbox_xmax"] = bbox.get("xmax", None)
            row["bbox_ymax"] = bbox.get("ymax", None)
            row["bbox_zmax"] = bbox.get("zmax", None)
            sx, sy, sz, xy_area, xy_ratio = bbox_spans(bbox)
            row["bbox_x_span"] = sx
            row["bbox_y_span"] = sy
            row["bbox_z_span"] = sz
            row["bbox_xy_area"] = xy_area
            row["bbox_xy_area_ratio"] = xy_ratio

        row["face_area_before"] = None
        row["face_area_after"]  = area
        row["diag_mm"]          = diag_mm

        rows.append(row)
        patch_global_id += 1
        n_added_records += 1

    # C. removed_faces
    n_removed_records = 0
    for fb in removed_faces:
        ib = safe_get(fb, "face_index", None)
        fb_info = before_faces_info[ib] if (isinstance(ib, int) and 0 <= ib < len(before_faces_info)) else None
        area = to_float(safe_get(fb, "area", safe_get(fb_info, "area"))) if (fb_info or ("area" in fb)) else None

        row = {k: None for k in fieldnames}
        row["uid"]             = uid
        row["patch_global_id"] = patch_global_id
        row["patch_type"]      = "removed_face"
        row["pair_id"]            = None
        row["before_face_index"]  = ib
        row["after_face_index"]   = None

        row["surf_type_before"]      = safe_get(fb, "surf_type", safe_get(fb_info, "surf_type"))
        row["surf_type_after"]       = None
        row["surf_type_code_before"] = safe_get(fb, "surf_type_code", safe_get(fb_info, "surf_type_code"))
        row["surf_type_code_after"]  = None

        row["delta_avg"] = 0.0
        row["delta_max"] = 0.0
        row["delta_min"] = 0.0
        row["n_samples"] = None
        row["area_est"]  = area
        row["sign"]      = "removed"

        row["delta_dir"]     = normalize_delta_dir("removed_face", row["sign"], 0.0)
        row["abs_delta_max"] = 0.0
        row["abs_delta_avg"] = 0.0

        nrm = extract_normal_any(fb, fb_info, None)
        if nrm is not None:
            nx, ny, nz = nrm
            row["normal_avg_x"] = nx
            row["normal_avg_y"] = ny
            row["normal_avg_z"] = nz
            row["normal_main_axis"] = main_axis_from_normal(nx, ny, nz)
            row["is_visible_zplus"] = visible_zplus_from_normal(nz)
            row["side_hint"]        = side_hint_from_normal(nz)
        else:
            row["normal_main_axis"] = None
            row["is_visible_zplus"] = None
            row["side_hint"]        = "UNKNOWN"

        center = safe_get(fb, "center", safe_get(fb_info, "center"))
        if isinstance(center, list) and len(center) == 3:
            row["center_x"], row["center_y"], row["center_z"] = center[0], center[1], center[2]

        bbox = safe_get(fb, "bbox", safe_get(fb_info, "bbox"))
        if isinstance(bbox, dict):
            row["bbox_xmin"] = bbox.get("xmin", None)
            row["bbox_ymin"] = bbox.get("ymin", None)
            row["bbox_zmin"] = bbox.get("zmin", None)
            row["bbox_xmax"] = bbox.get("xmax", None)
            row["bbox_ymax"] = bbox.get("ymax", None)
            row["bbox_zmax"] = bbox.get("zmax", None)
            sx, sy, sz, xy_area, xy_ratio = bbox_spans(bbox)
            row["bbox_x_span"] = sx
            row["bbox_y_span"] = sy
            row["bbox_z_span"] = sz
            row["bbox_xy_area"] = xy_area
            row["bbox_xy_area_ratio"] = xy_ratio

        row["face_area_before"] = area
        row["face_area_after"]  = None
        row["diag_mm"]          = diag_mm

        rows.append(row)
        patch_global_id += 1
        n_removed_records += 1

    # D. save CSV
    print(f"  total records        : {len(rows)}")

    with open(csv_path, "w", encoding="utf-8-sig", newline="") as f_csv:
        writer = csv.DictWriter(f_csv, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)

    # E. save SUMMARY JSON
    summary = {
        "uid": uid,
        "diag_mm": diag_mm,
        "params_from_03S": params_03S,
        "stats": {
            "n_pair_patches_total": len(pair_patches),
            "n_pair_patches_with_change": n_pair_with_change,
            "n_pair_patch_records": n_pair_patch_records,
            "n_added_faces_in_03S": len(added_faces),
            "n_removed_faces_in_03S": len(removed_faces),
            "n_added_records": n_added_records,
            "n_removed_records": n_removed_records,
            "n_total_records": len(rows),
        },
    }
    with open(summary_path, "w", encoding="utf-8") as f_sum:
        json.dump(summary, f_sum, ensure_ascii=False, indent=2)

    print(f"[{uid}] saved SUMMARY  : {summary_path}")
    print(f"[{uid}] saved FEATURES : {csv_path}")
    print(f"[{uid}] elapsed        : {time.time() - t0:.1f} s")

# ----------------- main -----------------
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--uid", default=None, help="single UID process (LIVE_* allowed)")
    parser.add_argument("--force", action="store_true", help="rebuild even if CSV exists")
    # compatibility (ignored)
    parser.add_argument("--before", default=None)
    parser.add_argument("--after",  default=None)
    parser.add_argument("--root",   default=None)
    # accept unknown args safely
    args, _ = parser.parse_known_args()

    # 경로 재설정 (전역 변수 의존성 제거를 위해 인자로 root가 들어오면 사용)
    global BASE_DIR, SCAN_DIR, UV_DIFF_DIR, OUT_BASE_DIR
    BASE_DIR = resolve_root(args.root)
    SCAN_DIR = os.path.join(BASE_DIR, "01S_FACE_SCAN")
    UV_DIFF_DIR = os.path.join(BASE_DIR, "03S_FACE_UV_DIFF")
    OUT_BASE_DIR = os.path.join(BASE_DIR, "04S_FACE_PATCH")
    ensure_dir(OUT_BASE_DIR)

    env_force = os.environ.get("SF5_FORCE_REBUILD", "0") == "1"

    if args.uid or (args.before and args.after):
        uid = _norm_uid(args.uid if args.uid else "LIVE_001")
        print("===== 04S : SINGLE MODE =====")
        print("  UID =", uid)
        process_one_uid(uid, force=(args.force or env_force))
        print("===== 04S : SINGLE DONE =====")
        return

    print("===== 04S : BATCH MODE =====")
    for uid in UID_LIST:
        try:
            process_one_uid(uid, force=(args.force or env_force))
        except Exception as e:
            import traceback
            print(f"exception on {uid}: {e}")
            traceback.print_exc()
    print("===== 04S : BATCH DONE =====")

if __name__ == "__main__":
    main()