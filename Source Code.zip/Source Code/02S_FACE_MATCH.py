# ============================================================
# 02S_FACE_MATCH.py  (ONLINE/BATCH – 파이프라인 호환 완전 교체판)
# 입력 : C:\sf5\sfsdh3\01S_FACE_SCAN\<uid>\<uid>_FACE_INFO.json
# 출력 : C:\sf5\sfsdh3\02S_FACE_MATCH\<uid>\<uid>_FACE_MATCH.json
# 사용 :
#   - 단일: python 02S_FACE_MATCH.py --uid LIVE_001 [--force]
#   - 배치: python 02S_FACE_MATCH.py
# ============================================================

import os
import sys
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import json
import math
import time
import argparse
from typing import Dict, Any, Tuple
import numpy as np

# ----------------- 경로/출력 유틸 -----------------
def safe_print(*args):
    msg = " ".join(str(a) for a in args)
    try:
        print(msg)
    except UnicodeEncodeError:
        try:
            sys.stdout.buffer.write((msg + "\n").encode("utf-8", errors="ignore"))
        except Exception:
            pass

def resolve_root(root_cli=None):
    if root_cli: return os.path.abspath(root_cli)
    env_root = os.environ.get("SF5_ROOT", "").strip()
    if env_root: return os.path.abspath(env_root)
    # 기본값: 스크립트 상위 폴더
    here = os.path.abspath(os.path.dirname(__file__))
    return os.path.abspath(os.path.join(here, ".."))

# 기본 설정
BASE_DIR = resolve_root()
SCAN_DIR = os.path.join(BASE_DIR, "01S_FACE_SCAN")
OUT_DIR  = os.path.join(BASE_DIR, "02S_FACE_MATCH")

# 배치 기본 범위
UID_LIST = [f"UID_{i:03d}" for i in range(1, 15)]

# KDTree 선택적 사용
_USE_KDTREE = True
try:
    from scipy.spatial import cKDTree
except Exception:
    _USE_KDTREE = False
    safe_print("[WARN] scipy.spatial.cKDTree not found -> using brute-force matching")

MATCH_PARAMS = {
    "k_candidates": 5,
    "max_area_diff_ratio_match": 0.30,
    "max_diag_diff_ratio_match": 0.20,
    "max_center_dist_norm_match": 0.05,
    "min_normal_dot_match": 0.90,
    "suspect_area_diff_ratio_min": 0.02,
    "suspect_diag_diff_ratio_min": 0.02,
    "suspect_center_dist_norm_min": 0.01,
}

def _safe_norm(v: np.ndarray) -> float:
    return float(np.linalg.norm(v))

def _unit(v: np.ndarray) -> np.ndarray:
    n = _safe_norm(v)
    return v / n if n > 0 else v

def _face_feat(face: Dict[str, Any], diag_global: float) -> np.ndarray:
    center = np.array(face.get("center", [0, 0, 0]), dtype=np.float64)
    normal = np.array(face.get("normal_avg", [0, 0, 1]), dtype=np.float64)
    area   = float(face.get("area", 1e-9))
    bbox_d = float(face.get("bbox_diag", 1e-9))

    if not np.isfinite(diag_global) or diag_global <= 0:
        diag_global = 1.0

    feat = np.zeros(8, dtype=np.float64)
    feat[0:3] = center / diag_global
    feat[3]   = math.log(max(area, 1e-9))
    feat[4]   = bbox_d / diag_global
    feat[5:8] = _unit(normal)
    return feat

def _geom_metrics(fb: Dict[str, Any], fa: Dict[str, Any], diag_global: float) -> Dict[str, float]:
    area_b = float(fb.get("area", 1e-9))
    area_a = float(fa.get("area", 1e-9))
    d_b    = float(fb.get("bbox_diag", 1e-9))
    d_a    = float(fa.get("bbox_diag", 1e-9))
    cb     = np.array(fb.get("center", [0, 0, 0]), dtype=np.float64)
    ca     = np.array(fa.get("center", [0, 0, 0]), dtype=np.float64)
    nb     = _unit(np.array(fb.get("normal_avg", [0, 0, 1]), dtype=np.float64))
    na     = _unit(np.array(fa.get("normal_avg", [0, 0, 1]), dtype=np.float64))

    area_max = max(area_b, area_a, 1e-9)
    diag_max = max(d_b, d_a, 1e-9)

    area_diff_ratio = abs(area_b - area_a) / area_max
    diag_diff_ratio = abs(d_b - d_a) / diag_max

    if not np.isfinite(diag_global) or diag_global <= 0:
        diag_global = 1.0
    center_dist_norm = _safe_norm(cb - ca) / diag_global
    normal_dot = float(np.clip(float(np.dot(nb, na)), -1.0, 1.0))

    return {
        "area_diff_ratio": area_diff_ratio,
        "diag_diff_ratio": diag_diff_ratio,
        "center_dist_norm": center_dist_norm,
        "normal_dot": normal_dot,
    }

def _bruteforce_topk(featA: np.ndarray, q: np.ndarray, k: int) -> Tuple[np.ndarray, np.ndarray]:
    d = np.linalg.norm(featA - q[None, :], axis=1)
    k = min(k, featA.shape[0])
    idx = np.argpartition(d, kth=k-1)[:k]
    ord_ = np.argsort(d[idx])
    idx = idx[ord_]
    return d[idx], idx

def process_one_uid(root: str, uid: str, force: bool = False):
    safe_print("\n==================================================")
    safe_print(f"[{uid}] 02S_FACE_MATCH 시작")

    # 경로 재구성 (인자로 받은 root 기준)
    scan_dir_local = os.path.join(root, "01S_FACE_SCAN")
    out_dir_local = os.path.join(root, "02S_FACE_MATCH")
    
    in_dir  = os.path.join(scan_dir_local, uid)
    in_path = os.path.join(in_dir,  f"{uid}_FACE_INFO.json")
    
    target_out_dir = os.path.join(out_dir_local, uid)
    os.makedirs(target_out_dir, exist_ok=True)
    out_path = os.path.join(target_out_dir, f"{uid}_FACE_MATCH.json")

    env_force = os.environ.get("SF5_FORCE_REBUILD", "0") == "1"
    if os.path.isfile(out_path) and not (force or env_force):
        safe_print(f"[{uid}] 기존 MATCH JSON 존재. 재사용: {out_path}")
        return

    if not os.path.isfile(in_path):
        safe_print(f"[{uid}] 입력(FACE_INFO) 없음. 스킵: {in_path}")
        return

    safe_print("입력 :", in_path)
    safe_print("출력 :", out_path, "(덮어쓰기)")
    t0 = time.time()

    with open(in_path, "r", encoding="utf-8") as f:
        info = json.load(f)

    diag_global  = float(info.get("diag_mm", 1.0))
    before_faces = info.get("before", {}).get("faces", [])
    after_faces  = info.get("after",  {}).get("faces", [])

    nB = len(before_faces)
    nA = len(after_faces)
    safe_print(f"before faces: {nB}")
    safe_print(f"after  faces: {nA}")

    if nB == 0 or nA == 0:
        data_out = {
            "uid": uid,
            "diag_mm": diag_global,
            "match_params": MATCH_PARAMS,
            "pairs": [],
            "before_only": list(range(nB)),
            "after_only": list(range(nA)),
        }
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(data_out, f, ensure_ascii=False, indent=2)
        safe_print(f"[{uid}] 빈 MATCH JSON 저장")
        safe_print(f"[{uid}] time {time.time()-t0:.1f}s")
        return

    featB = np.vstack([_face_feat(fb, diag_global) for fb in before_faces])
    featA = np.vstack([_face_feat(fa, diag_global) for fa in after_faces])

    k = MATCH_PARAMS["k_candidates"]
    if _USE_KDTREE:
        treeA = cKDTree(featA)

    max_area_r   = MATCH_PARAMS["max_area_diff_ratio_match"]
    max_diag_r   = MATCH_PARAMS["max_diag_diff_ratio_match"]
    max_center_n = MATCH_PARAMS["max_center_dist_norm_match"]
    min_ndot     = MATCH_PARAMS["min_normal_dot_match"]

    sus_area_min   = MATCH_PARAMS["suspect_area_diff_ratio_min"]
    sus_diag_min   = MATCH_PARAMS["suspect_diag_diff_ratio_min"]
    sus_center_min = MATCH_PARAMS["suspect_center_dist_norm_min"]

    used_after = set()
    pairs = []

    for ib, fb in enumerate(before_faces):
        q = featB[ib, :]
        if _USE_KDTREE:
            dists, idxs = treeA.query(q, k=min(k, nA))
            if np.isscalar(idxs):
                idxs = np.array([int(idxs)], dtype=np.int64)
                dists = np.array([float(dists)], dtype=np.float64)
        else:
            dists, idxs = _bruteforce_topk(featA, q, k=min(k, nA))

        best = None
        best_score = None

        for dist, ia in zip(dists, idxs):
            ia = int(ia)
            if ia in used_after:
                continue

            fa = after_faces[ia]
            met = _geom_metrics(fb, fa, diag_global)

            if met["area_diff_ratio"]   > max_area_r:   continue
            if met["diag_diff_ratio"]   > max_diag_r:   continue
            if met["center_dist_norm"]  > max_center_n: continue
            if met["normal_dot"]        < min_ndot:     continue

            score = float(dist + 0.5*met["area_diff_ratio"] + 0.5*met["diag_diff_ratio"])
            if (best_score is None) or (score < best_score):
                best = (ia, met, score); best_score = score

        if best is None:
            continue

        ia, met, score = best
        used_after.add(ia)

        suspect = (
            (met["area_diff_ratio"]  >= sus_area_min) or
            (met["diag_diff_ratio"]  >= sus_diag_min) or
            (met["center_dist_norm"] >= sus_center_min)
        )

        pairs.append({
            "pair_id": len(pairs),
            "before_face_index": ib,
            "after_face_index": ia,
            "score_kdtree": float(score),
            "area_diff_ratio": float(met["area_diff_ratio"]),
            "diag_diff_ratio": float(met["diag_diff_ratio"]),
            "center_dist_norm": float(met["center_dist_norm"]),
            "normal_dot": float(met["normal_dot"]),
            "suspect": bool(suspect),
        })

    matched_b = {p["before_face_index"] for p in pairs}
    matched_a = {p["after_face_index"]  for p in pairs}
    before_only = sorted(set(range(nB)) - matched_b)
    after_only  = sorted(set(range(nA)) - matched_a)

    data_out = {
        "uid": uid,
        "diag_mm": diag_global,
        "match_params": MATCH_PARAMS,
        "n_before": nB,
        "n_after": nA,
        "pairs": pairs,
        "before_only": before_only,
        "after_only": after_only,
    }

    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(data_out, f, ensure_ascii=False, indent=2)

    safe_print(f"[{uid}] MATCH JSON 저장 완료: {out_path}")
    safe_print(f"[{uid}] pairs {len(pairs)}, suspect {sum(p['suspect'] for p in pairs)}")
    safe_print(f"[{uid}] before_only {len(before_only)}, after_only {len(after_only)}")
    safe_print(f"[{uid}] time {time.time()-t0:.1f}s")

def main():
    ap = argparse.ArgumentParser()
    # 파이프라인/단일 실행 인자
    ap.add_argument("--uid",    default=None, help="단일 UID 처리 (LIVE_* 또는 UID_###)")
    ap.add_argument("--root",   default=None, help="프로젝트 루트 폴더")
    ap.add_argument("--force",  action="store_true", help="결과 존재해도 강제 재생성")

    # 파이프라인 호환용: 넘어와도 무시 (에러 방지)
    ap.add_argument("--uid_start", default=None)
    ap.add_argument("--uid_end",   default=None)
    ap.add_argument("--before",    default=None)
    ap.add_argument("--after",     default=None)

    args = ap.parse_args()

    # 루트 경로 확정
    root = resolve_root(args.root)
    # 전역 갱신 (process_one_uid가 사용하도록)
    global SCAN_DIR, OUT_DIR
    SCAN_DIR = os.path.join(root, "01S_FACE_SCAN")
    OUT_DIR  = os.path.join(root, "02S_FACE_MATCH")
    os.makedirs(OUT_DIR, exist_ok=True)

    # 1) 온라인 모드: --uid가 있으면 단일 실행
    if args.uid:
        process_one_uid(root, args.uid, force=args.force)
        return

    # 2) 배치 모드: --uid 없으면 기본 목록 순회
    safe_print("===== 02S_FACE_MATCH : BATCH =====")
    safe_print("ROOT =", root)
    
    # 범위 지정이 있으면 우선 (uid_start/end는 문자열일 수 있으므로 처리)
    if args.uid_start and args.uid_end:
        try:
            start = int(args.uid_start)
            end = int(args.uid_end)
            target_list = [f"UID_{i:03d}" for i in range(start, end + 1)]
        except:
            target_list = UID_LIST
    else:
        target_list = UID_LIST

    for uid in target_list:
        try:
            process_one_uid(root, uid, force=args.force)
        except Exception as e:
            import traceback
            safe_print(f"[WARN] {uid} 처리 중 예외: {e}")
            traceback.print_exc()
            
    safe_print("===== 02S_FACE_MATCH : BATCH DONE =====")

if __name__ == "__main__":
    main()