# -*- coding: utf-8 -*-
# =============================================================================
# 07S_PATCH_LABEL_AUTO_LOCAL.py (FINAL PATH FIX)
#
# [수정 사항]
# - 경로 설정(resolve_root) 로직 수정: 무조건 상위로 가지 않고, 현재 폴더에 데이터가 있으면 현재를 루트로 인식
# - 기능: 물리적 가공 시뮬레이션 기반 상세 견적(설계/NC/방전/전극/사상/기타) 산출 유지
# =============================================================================

import os
import re
import math
import argparse
import logging
import time
from typing import Optional, Dict, Any, Tuple, List
import numpy as np
import pandas as pd

# -----------------------------------------------------------------------------
# 1. 환경 설정 및 로거 초기화
# -----------------------------------------------------------------------------
def resolve_root(root_cli=None):
    """
    [핵심 수정] 실행 위치 기반 루트 경로 지능형 탐색
    """
    if root_cli: return os.path.abspath(root_cli)
    
    env_root = os.environ.get("SF5_ROOT", "").strip()
    if env_root: return os.path.abspath(env_root)
    
    here = os.path.abspath(os.path.dirname(__file__))
    
    # 1. 현재 위치에 05S 폴더가 있으면, 현재 위치가 ROOT임 (C:\sf5\sfsdh3)
    if os.path.isdir(os.path.join(here, "05S_PATCH_DATA")):
        return here
        
    # 2. 없으면 상위 폴더 확인 (agent_core 내부에서 실행될 경우 등)
    parent = os.path.abspath(os.path.join(here, ".."))
    if os.path.isdir(os.path.join(parent, "05S_PATCH_DATA")):
        return parent
        
    # 3. 그래도 없으면 현재 위치 반환 (오류 메시지에서 경로 확인 용이하게)
    return here

ROOT_DIR = resolve_root()
IN_CSV   = os.path.join(ROOT_DIR, "05S_PATCH_DATA", "S_PATCH_FEATURES_ALL_UIDS.csv")
OUT_DIR  = os.path.join(ROOT_DIR, "07S_PATCH_LABEL")
os.makedirs(OUT_DIR, exist_ok=True)

logging.basicConfig(level=logging.INFO, format='[%(levelname)s] %(message)s')
logger = logging.getLogger("07S_EXPERT")

def _s(txt):
    return str(txt).encode("ascii", "ignore").decode("ascii")

def _print(msg):
    print(_s(msg))

# -----------------------------------------------------------------------------
# 2. Expert Knowledge Base (가공 데이터베이스)
# -----------------------------------------------------------------------------

# 2-1. 공정별 시간당 임률 (Hourly Rate, 단위: 원)
# 유재성님 피드백 반영: 현실적인 수준으로 조정하되, 설비 감가상각과 인건비를 고려하여 차등 적용
RATES = {
    "DESIGN": 45000.0,   # 설계/CAM (S/W 라이선스 + 고급 인력)
    "CNC_3AX": 50000.0,  # 범용 3축 가공
    "CNC_5AX": 90000.0,  # 5축 정밀 가공 (고가 장비)
    "EDM":    60000.0,   # 방전 가공 (전력비 + 소모품)
    "ELEC":   45000.0,   # 전극 가공 (흑연/동)
    "POLISH": 40000.0,   # 사상/래핑 (순수 인건비)
    "WELD":   80000.0,   # 레이저/알곤 용접 (특수 기술료)
    "ETC":    35000.0,   # 셋업/대기/검사
}

# 2-2. 가공 효율 파라미터 (Physics Parameters)
# MRR: Material Removal Rate (mm^3/min)
# AREA_RATE: Area Coverage Rate (mm^2/min)
PARAMS = {
    # [NC 가공]
    "MRR_ROUGH_SOFT": 6000.0,   # 연강 황삭
    "MRR_ROUGH_HARD": 3000.0,   # 경강 황삭 (열처리강)
    "MRR_FINISH":     400.0,    # 정삭 (면적 기준 환산 속도, 피치 0.1mm 가정)
    "FEED_MICRO":     100.0,    # 미세 가공 이송 속도 (mm/min)
    
    # [방전 가공]
    "EDM_SPEED_ROUGH": 30.0,    # 방전 황삭 (mm^3/min)
    "EDM_SPEED_FINISH": 5.0,    # 방전 정삭 (mm^3/min) - 매우 느림
    
    # [기타]
    "POLISH_SPEED":   100.0,    # 사상 속도 (mm^2/min)
    "WELD_SPEED":     20.0,     # 용접 속도 (mm^2/min)
}

# -----------------------------------------------------------------------------
# 3. 유틸리티 함수
# -----------------------------------------------------------------------------
def safe_float(val, default=0.0):
    try:
        if pd.isna(val) or val is None: return default
        return float(val)
    except: return default

def get_uid_str(val):
    if val is None: return None
    s = str(val).strip()
    nums = re.findall(r"\d+", s)
    if nums: return str(int(nums[-1])).zfill(3)
    return None

# -----------------------------------------------------------------------------
# 4. Expert System Core Class (상세 견적 시뮬레이터)
# -----------------------------------------------------------------------------
class DetailedEstimator:
    def __init__(self):
        # 재질 설정 (기본 NAK80 가정)
        self.material_factor = 1.0 # 가공성 계수 (1.0 기준)

    def analyze_geometry(self, row):
        """
        [Step 1] 형상학적 특징 추출 (Geometric Feature Extraction)
        CSV의 수치 데이터를 기반으로 금형 전문가의 관점에서 형상을 해석합니다.
        """
        area = max(safe_float(row.get("area_est")), 1.0)
        d_max = safe_float(row.get("delta_max"))
        depth = max(abs(d_max), 0.1)
        
        # Bounding Box Logic
        z_span = safe_float(row.get("bbox_z_span"))
        xy_area = safe_float(row.get("bbox_xy_area"))
        
        # 깊이 비율 (Depth Ratio) 계산: 가공 난이도의 핵심 지표
        # 폭(Width) 추정 = sqrt(xy_area)
        width_est = math.sqrt(xy_area) if xy_area > 0 else 1.0
        depth_ratio = z_span / width_est if width_est > 0 else 0.0
        
        # 체적 (Volume) 근사
        volume = area * depth
        
        # 형상 분류 (Geometry Class)
        geom_cls = str(row.get("geom_class", "UNKNOWN")).upper()
        
        # 특수 속성 플래그
        is_rib = "RIB" in geom_cls
        is_surf = "SURF" in geom_cls or "CURVED" in geom_cls
        is_hole = "HOLE" in geom_cls or "BOSS" in geom_cls
        is_tiny = area < 10.0  # 미세 형상
        
        return {
            "area": area,
            "depth": depth,
            "volume": volume,
            "depth_ratio": depth_ratio,
            "geom_cls": geom_cls,
            "is_rib": is_rib,
            "is_surf": is_surf,
            "is_hole": is_hole,
            "is_tiny": is_tiny
        }

    def estimate_breakdown(self, row):
        """
        [Step 2] 공정별 상세 시간/비용 산출 (Simulation)
        형상 특징을 바탕으로 각 공정(Design, CNC, EDM...)의 소요 시간을 시뮬레이션합니다.
        """
        geo = self.analyze_geometry(row)
        
        # --- 결과 변수 초기화 (분 단위) ---
        t_design = 0.0  # 설계/CAM
        t_cnc    = 0.0  # 기계가공
        t_edm    = 0.0  # 방전가공
        t_elec   = 0.0  # 전극제작
        t_polish = 0.0  # 사상
        t_weld   = 0.0  # 용접
        t_etc    = 0.0  # 셋업/기타
        
        # 공정 선정 근거 기록용
        reasons = [] 

        # -------------------------------------------------
        # 1. 설계/CAM (Design)
        # -------------------------------------------------
        # 기본 데이터 처리 시간 20분
        t_design = 20.0
        
        # 복잡도에 따른 할증
        if geo["depth_ratio"] > 1.5: 
            t_design += 20.0 # 방전 전극 설계 필요 가능성
        if geo["is_surf"]: 
            t_design += 30.0 # 3D 곡면 CAM 연산 시간 증가
        
        reasons.append("기본 설계/CAM")

        # -------------------------------------------------
        # 2. 용접 (Welding) - 살붙임(Added) 특례
        # -------------------------------------------------
        ptype = str(row.get("patch_type", "")).lower()
        if "added" in ptype and geo["depth"] > 2.0:
            # 깊이가 2mm 이상 추가되면 육성 용접 필요하다고 판단
            t_weld = geo["area"] / PARAMS["WELD_SPEED"]
            t_etc += 20.0 # 용접 예열 및 후처리
            reasons.append(f"두께 {geo['depth']:.1f}mm 육성 용접")
        
        # -------------------------------------------------
        # 3. 메인 가공 공정 판별 (CNC vs EDM Decision)
        # -------------------------------------------------
        # [판단 로직]
        # 1. 깊이비(Depth Ratio)가 1.2를 넘으면서 면적이 좁으면(3000 이하) -> 방전
        # 2. 리브(RIB) 형상이면서 깊이비가 0.8만 넘어도 -> 방전 (리브는 엔드밀 진입 불가)
        # 3. 그 외 -> CNC 절삭
        
        use_edm = False
        if (geo["depth_ratio"] > 1.2 and geo["area"] < 3000) or (geo["is_rib"] and geo["depth_ratio"] > 0.8):
            use_edm = True
            
        if use_edm:
            # === [방전(EDM) 프로세스] ===
            reasons.append(f"심부 형상(비율 {geo['depth_ratio']:.1f}) 방전 적용")
            
            # (A) 전극 개수 산정
            n_elec = 2 # 기본: 황삭/정삭
            if geo["depth_ratio"] > 3.0: 
                n_elec = 3 # 아주 깊으면 황/중/정 3개
                reasons.append("다단 전극(3EA)")
            
            # (B) 전극 제작 시간 (Electrode Making)
            # 전극 하나당 CNC 가공 + 검사 시간 (평균 50분)
            t_elec = n_elec * 50.0 
            
            # (C) 방전 가공 시간 (EDM Burning)
            # 부피를 방전 속도로 나눔
            # 깊이가 깊으면 슬러지 배출 곤란으로 효율 저하 (패널티 적용)
            eff_factor = 1.0
            if geo["depth_ratio"] > 2.0: eff_factor = 0.6 # 효율 60%로 감소
            
            t_edm = geo["volume"] / (PARAMS["EDM_SPEED_FINISH"] * eff_factor)
            
            # (D) CNC 보조 가공
            # 전극이 닿지 않는 상단부나 기준면 가공
            t_cnc = 15.0 
            
            # (E) 셋업 시간
            # 전극 개수만큼 셋업 및 위치 보정
            t_etc += n_elec * 15.0
            
            main_process_name = "EDM"
            
        else:
            # === [절삭(CNC) 프로세스] ===
            
            # (A) 황삭 (Roughing) - 부피 제거
            t_rough = geo["volume"] / PARAMS["MRR_ROUGH_HARD"]
            
            # (B) 정삭 (Finishing) - 표면적 스캔
            t_finish = geo["area"] / PARAMS["MRR_FINISH"]
            
            # (C) 곡면/5축 가중치
            if geo["is_surf"]: 
                t_finish *= 2.0 # 곡면은 볼엔드밀 피치를 촘촘하게 타야 함
                reasons.append("3D 곡면 정삭")
                main_process_name = "CNC_5AX"
            else:
                reasons.append("NC 직가공")
                main_process_name = "CNC_3AX"
            
            # (D) 미세 형상 가중치
            if geo["is_tiny"]:
                t_finish *= 1.5 # 소경 공구는 피드가 느림
                reasons.append("미세 정밀 가공")
            
            t_cnc = t_rough + t_finish
            
            # (E) 셋업
            t_etc += 20.0 # 공작물 셋업 및 원점 세팅

        # -------------------------------------------------
        # 4. 사상 (Polishing)
        # -------------------------------------------------
        # 면적 비례 수작업 시간
        t_polish = geo["area"] / PARAMS["POLISH_SPEED"]
        
        # 방전면은 경화층 제거(White Layer) 때문에 사상이 더 오래 걸림
        if use_edm: 
            t_polish *= 1.5 
            reasons.append("방전면 사상")
        
        # -------------------------------------------------
        # 5. 최종 집계 및 비용 환산
        # -------------------------------------------------
        # 최소 시간 보정 (10분 미만은 10분으로 - 기본 세팅값)
        total_check = t_design + t_cnc + t_edm + t_elec + t_polish + t_weld + t_etc
        if total_check < 10.0:
            t_etc += (10.0 - total_check) # 부족분은 기타 시간으로 보정
            
        t_total = t_design + t_cnc + t_edm + t_elec + t_polish + t_weld + t_etc
        
        # 공정별 비용 계산 (시간 * 해당 공정 임률)
        # 시간은 분 단위이므로 /60.0 필수
        cost_design = (t_design / 60.0) * RATES["DESIGN"]
        cost_cnc    = (t_cnc / 60.0)    * (RATES["CNC_5AX"] if main_process_name=="CNC_5AX" else RATES["CNC_3AX"])
        cost_edm    = (t_edm / 60.0)    * RATES["EDM"]
        cost_elec   = (t_elec / 60.0)   * RATES["ELEC"]
        cost_polish = (t_polish / 60.0) * RATES["POLISH"]
        cost_weld   = (t_weld / 60.0)   * RATES["WELD"]
        cost_etc    = (t_etc / 60.0)    * RATES["ETC"]
        
        total_cost = cost_design + cost_cnc + cost_edm + cost_elec + cost_polish + cost_weld + cost_etc
        
        return {
            "time_total":  round(t_total, 1),
            "cost_total":  int(total_cost),
            "time_design": round(t_design, 1),
            "time_cnc":    round(t_cnc, 1),
            "time_edm":    round(t_edm, 1),
            "time_elec":   round(t_elec, 1),
            "time_polish": round(t_polish, 1),
            "time_weld":   round(t_weld, 1),
            "time_etc":    round(t_etc, 1),
            "process_main": main_process_name,
            "reason":      ", ".join(reasons)
        }

# -----------------------------------------------------------------------------
# 5. 실행 로직
# -----------------------------------------------------------------------------
def process_dataframe(df: pd.DataFrame, estimator: DetailedEstimator):
    # 피처 보강 (NaN 처리)
    cols = ["delta_max", "area_est", "bbox_z_span", "bbox_xy_area", "normal_avg_z"]
    for c in cols:
        if c not in df.columns: df[c] = 0.0
        df[c] = pd.to_numeric(df[c], errors='coerce').fillna(0.0)
    
    results = []
    for idx, row in df.iterrows():
        try:
            res = estimator.estimate_breakdown(row)
            results.append(res)
        except Exception as e:
            logger.error(f"Row {idx} calculation failed: {e}")
            # Fallback (실패 시 기본값)
            results.append({
                "time_total": 30.0, "cost_total": 30000, 
                "time_design": 10, "time_cnc": 10, "time_edm":0, 
                "time_elec":0, "time_polish":5, "time_weld":0, "time_etc":5,
                "process_main": "FAIL", "reason": "산출 실패(기본값)"
            })
            
    res_df = pd.DataFrame(results)
    
    # [중요] 기존 컬럼(Total) 업데이트
    df["time_min_auto"] = res_df["time_total"]
    df["cost_krw_auto"] = res_df["cost_total"]
    
    # [신규] 상세 컬럼 추가 (17R에서 역배분할 때 사용될 핵심 데이터)
    df["time_design_auto"] = res_df["time_design"]
    df["time_cnc_auto"]    = res_df["time_cnc"]
    df["time_edm_auto"]    = res_df["time_edm"]
    df["time_elec_auto"]   = res_df["time_elec"]
    df["time_polish_auto"] = res_df["time_polish"]
    df["time_weld_auto"]   = res_df["time_weld"]
    df["time_etc_auto"]    = res_df["time_etc"]
    
    df["process_family_auto"] = res_df["process_main"]
    df["why_process_ko"]      = res_df["reason"]
    
    # RAG용 텍스트 보강
    df["why_geom_ko"] = df.apply(lambda r: f"형상: {r.get('geom_class_auto','기타')}", axis=1)
    
    return df

def load_input():
    if not os.path.isfile(IN_CSV):
        raise FileNotFoundError(f"[07S] CSV not found: {IN_CSV}")
    try:
        return pd.read_csv(IN_CSV, encoding="utf-8-sig")
    except:
        return pd.read_csv(IN_CSV, encoding="cp949")

def save_csv(df, path):
    df.to_csv(path, index=False, encoding="utf-8-sig")
    _print(f"[SAVE] {path}")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--uid", default=None)
    parser.add_argument("--root", default=None)
    parser.add_argument("--before", default=None)
    parser.add_argument("--after",  default=None)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    global ROOT_DIR, IN_CSV, OUT_DIR
    if args.root:
        ROOT_DIR = resolve_root(args.root)
        IN_CSV   = os.path.join(ROOT_DIR, "05S_PATCH_DATA", "S_PATCH_FEATURES_ALL_UIDS.csv")
        OUT_DIR  = os.path.join(ROOT_DIR, "07S_PATCH_LABEL")
        os.makedirs(OUT_DIR, exist_ok=True)

    _print("==================================================")
    _print("===== 07S DETAIL ESTIMATION (V4 - PATH FIX) =====")
    
    if not os.path.exists(IN_CSV):
        _print(f"[ERROR] Input CSV not found: {IN_CSV}")
        # 파일이 없을 경우 대비
        return

    df = load_input()
    estimator = DetailedEstimator()
    
    if args.uid:
        # Online Mode (단일 UID 처리)
        u_nums = re.findall(r"\d+", str(args.uid))
        if u_nums:
            target_uid = f"UID_{int(u_nums[-1]):03d}"
            # 문자열 포함 여부로 필터링 (주의: uid 컬럼이 숫자형일수도, 문자형일수도 있음)
            df_sub = df[df["uid"].astype(str).str.contains(str(int(u_nums[-1])))]
            
            if df_sub.empty:
                _print(f"[07S][WARN] No data for {args.uid}. Creating dummy.")
                dummy_path = os.path.join(OUT_DIR, f"{target_uid}_PATCH_LABEL_TEMPLATE.csv")
                # 더미 파일이라도 컬럼은 맞춰줘야 파이프라인이 안 죽음
                pd.DataFrame(columns=["uid","time_min_auto","cost_krw_auto"]).to_csv(dummy_path, index=False)
                return
                
            df_labeled = process_dataframe(df_sub.copy(), estimator)
            out_path = os.path.join(OUT_DIR, f"{target_uid}_PATCH_LABEL_TEMPLATE.csv")
            save_csv(df_labeled, out_path)
        else:
            _print(f"[07S][ERROR] Invalid UID: {args.uid}")
    else:
        # Batch Mode (전체 처리)
        df_labeled = process_dataframe(df.copy(), estimator)
        out_path = os.path.join(OUT_DIR, "S_PATCH_LABEL_TEMPLATE.csv")
        save_csv(df_labeled, out_path)

    _print("===== 07S DONE =====")

if __name__ == "__main__":
    main()