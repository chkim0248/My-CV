# ============================================================
# 05S_PATCH_MERGE_DATA.py  (FINAL FIX: Accept --force arg)
#
# 역할
#   - 04S 폴더의 CSV를 마스터 CSV로 병합
#   - 수정: s_pipeline에서 보내는 --force 인자를 받을 수 있도록 ArgumentParser 수정
#   - 보존: UID 1000번대 이상 처리 및 폴더 누락 시 안전 스킵 로직 100% 유지
# ============================================================

import os
import glob
import pandas as pd
import argparse
import re
import sys

# ----------------- 경로 리졸버 -----------------
def resolve_root(root_cli=None):
    if root_cli: return os.path.abspath(root_cli)
    env_root = os.environ.get("SF5_ROOT", "").strip()
    if env_root: return os.path.abspath(env_root)
    here = os.path.abspath(os.path.dirname(__file__))
    return os.path.abspath(os.path.join(here, ".."))

# ----------------- 메인 로직 -----------------
def main(only_uid=None, force=False):
    ROOT_DIR = resolve_root() 
    PATCH_DIR = os.path.join(ROOT_DIR, "04S_FACE_PATCH")
    OUT_DIR   = os.path.join(ROOT_DIR, "05S_PATCH_DATA")
    os.makedirs(OUT_DIR, exist_ok=True)
    OUT_CSV_PATH = os.path.join(OUT_DIR, "S_PATCH_FEATURES_ALL_UIDS.csv")

    print(f"===== 05S START (Safe Mode) =====")
    
    # 1. 대상 폴더 찾기
    uid_folders = []
    
    if only_uid is not None:
        # UID 파싱 (193914 등 큰 숫자 대응)
        nums = re.findall(r"\d+", str(only_uid))
        if nums:
            target_num = int(nums[-1])
            # "UID_193914" 형태로 추정
            target_folder_name = f"UID_{target_num:03d}"
            target_path = os.path.join(PATCH_DIR, target_folder_name)
            
            # 폴더가 없으면 죽는 게 아니라, 검색을 시도하거나 스킵
            if os.path.isdir(target_path):
                uid_folders = [target_path]
                print(f"[05S] Found Target: {target_folder_name}")
            else:
                # 혹시 폴더명이 다를 수 있으니 검색 시도 (숫자 포함된 폴더)
                candidates = glob.glob(os.path.join(PATCH_DIR, f"*{target_num}*"))
                valid_cands = [p for p in candidates if os.path.isdir(p)]
                
                if valid_cands:
                    uid_folders = valid_cands
                    print(f"[05S] Found via glob: {valid_cands[0]}")
                else:
                    # 없으면 죽지 않고 경고만 출력하고 정상 종료 (Code 0)
                    print(f"[05S][WARN] Target folder not found for {only_uid}. Skipping merge.")
                    if not os.path.exists(OUT_CSV_PATH):
                        pd.DataFrame(columns=["uid", "patch_global_id"]).to_csv(OUT_CSV_PATH, index=False)
                    sys.exit(0) 
        else:
            print(f"[05S][WARN] Invalid UID format: {only_uid}. Skipping.")
            sys.exit(0)
    else:
        # 배치 모드
        uid_folders = sorted(glob.glob(os.path.join(PATCH_DIR, "UID_*")))

    if not uid_folders:
        print("[05S] No folders to process.")
        sys.exit(0)

    # 2. 데이터 병합
    dfs = []
    
    for uf in uid_folders:
        uid_tag = os.path.basename(uf)
        csv_path = os.path.join(uf, f"{uid_tag}_PATCH_FEATURES.csv")
        
        if not os.path.isfile(csv_path):
            # 파일 이름이 다를 수도 있으니 폴더 내 csv 검색
            csvs = glob.glob(os.path.join(uf, "*.csv"))
            if csvs: csv_path = csvs[0]
            else: continue

        try:
            try: df = pd.read_csv(csv_path, encoding="utf-8-sig")
            except: df = pd.read_csv(csv_path, encoding="cp949")
            
            if df.empty: continue
            
            # UID 컬럼 안전장치
            if "uid" not in df.columns:
                df["uid"] = uid_tag
            
            dfs.append(df)
        except Exception as e:
            print(f"[WARN] Read error {uid_tag}: {e}")
            continue

    if not dfs:
        print("[05S] No valid CSVs found to merge.")
        sys.exit(0)

    df_new = pd.concat(dfs, ignore_index=True, sort=False)

    # 3. 저장 (기존 데이터 유지 + 업데이트)
    # force가 True면 덮어쓰기를 선호할 수 있지만, 05S는 Master Data이므로
    # 보통은 Update 방식을 유지하는 게 데이터 보존에 유리함.
    if os.path.isfile(OUT_CSV_PATH):
        try:
            try: df_old = pd.read_csv(OUT_CSV_PATH, encoding="utf-8-sig")
            except: df_old = pd.read_csv(OUT_CSV_PATH, encoding="cp949")
            
            # 이번에 처리한 UID들은 기존에서 제거 (덮어쓰기)
            new_uids = set(df_new["uid"].unique())
            df_old = df_old[~df_old["uid"].isin(new_uids)]
            
            df_final = pd.concat([df_old, df_new], ignore_index=True, sort=False)
        except:
            df_final = df_new
    else:
        df_final = df_new

    # 컬럼 정렬
    cols = list(df_final.columns)
    front = ["uid", "UID", "patch_global_id", "patch_type"]
    new_order = [c for c in front if c in cols] + [c for c in cols if c not in front]
    df_final = df_final[new_order]

    df_final.to_csv(OUT_CSV_PATH, index=False, encoding="utf-8-sig")
    print(f"[05S] Success. Saved {len(df_final)} rows to {OUT_CSV_PATH}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--uid", default=None)
    parser.add_argument("--root", default=None)
    parser.add_argument("--before", default=None)
    parser.add_argument("--after", default=None)
    
    # [핵심 수정] 파이프라인 호환용 --force 인자 추가 (기능은 없더라도 에러 안 나게)
    parser.add_argument("--force", action="store_true", help="Force rebuild (accepted but handled internally)")
    
    args = parser.parse_args()
    
    main(args.uid, force=args.force)